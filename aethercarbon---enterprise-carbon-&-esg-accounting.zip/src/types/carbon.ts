export type EmissionScope = 'scope_1' | 'scope_2' | 'scope_3';

export type Scope1Category = 
  | 'stationary_combustion'
  | 'mobile_combustion'
  | 'process_emissions'
  | 'fugitive_refrigerants';

export type Scope2Category = 
  | 'purchased_electricity'
  | 'purchased_steam'
  | 'purchased_cooling'
  | 'district_heating';

export type Scope2Method = 'location_based' | 'market_based';

export type Scope3Category = 
  | 'cat_1_purchased_goods'
  | 'cat_2_capital_goods'
  | 'cat_3_fuel_energy_activities'
  | 'cat_4_upstream_transport'
  | 'cat_5_waste_operations'
  | 'cat_6_business_travel'
  | 'cat_7_employee_commuting'
  | 'cat_8_upstream_leased_assets'
  | 'cat_9_downstream_transport'
  | 'cat_11_use_of_sold_products'
  | 'cat_12_end_of_life';

export type DataQualityTier = 
  | 'Tier 1 (Supplier Primary / Continuous Meter)'
  | 'Tier 2 (Activity-specific / Regional Fuel Factor)'
  | 'Tier 3 (Spend-based Economic Model / Proxy)';

export type AuditVerificationStatus = 
  | 'auditor_verified'
  | 'ready_for_audit'
  | 'draft_review'
  | 'requires_clarification';

export interface ActivityRecord {
  id: string;
  date: string;
  facilityId: string;
  facilityName: string;
  scope: EmissionScope;
  category: Scope1Category | Scope2Category | Scope3Category;
  categoryLabel: string;
  activityName: string;
  quantity: number;
  unit: string;
  emissionFactorId: string;
  emissionFactorValue: number; // kgCO2e per unit
  emissionFactorUnit: string;
  factorSource: string; // 'DEFRA 2024' | 'EPA eGRID 2024' | 'IEA 2024' | 'EXIOBASE' | 'Supplier Primary'
  calculatedEmissionsTons: number; // tCO2e (metric tons)
  scope2Method?: Scope2Method;
  marketBasedDeductionTons?: number; // e.g. from bundled green tariff / EAC
  dataQualityTier: DataQualityTier;
  verificationStatus: AuditVerificationStatus;
  evidenceDocName?: string;
  evidenceDocUrl?: string;
  auditorNotes?: string;
  costUsd?: number;
  tags?: string[];
}

export interface Facility {
  id: string;
  name: string;
  code: string;
  city: string;
  country: string;
  gridRegion: string;
  floorAreaSqM: number;
  headcount: number;
  primaryEnergySource: string;
  renewablePpaPercent: number;
  annualRevenueUsdM: number;
}

export interface CarbonOffset {
  id: string;
  projectName: string;
  registry: 'Verra (VCS)' | 'Gold Standard' | 'Puro.earth (CDR)' | 'American Carbon Registry (ACR)';
  serialNumber: string;
  vintageYear: number;
  quantityTons: number;
  projectType: string;
  removalType: 'durable_removal' | 'avoidance';
  permanenceRatingYears: number; // e.g., 1000 for biochar/DAC, 40 for forestry
  additionalityScore: 'High' | 'Very High' | 'Audited';
  costPerTonUsd: number;
  status: 'active_in_portfolio' | 'retired_for_reporting';
  retirementDate?: string;
  beneficiaryEntity?: string;
  certificateRef: string;
}

export interface EACCertificate {
  id: string;
  certificateType: 'Guarantees of Origin (GO)' | 'US REC (eGRID)' | 'I-REC' | 'Green Power PPA';
  volumeMWh: number;
  facilityId: string;
  facilityName: string;
  generationSource: 'Wind' | 'Solar PV' | 'Hydro' | 'Biomass';
  vintageYear: number;
  serialNumber: string;
  retiredForPeriod: string;
  emissionsAvoidedTons: number;
  status: 'retired' | 'allocated';
}

export interface DecarbonizationLever {
  id: string;
  name: string;
  scopeImpacted: EmissionScope[];
  category: string;
  description: string;
  capexUsd: number;
  opexAnnualSavingsUsd: number;
  abatementTonsPerYear: number;
  costPerTonAbated: number; // $/tCO2e (Marginal Abatement Cost)
  implementationTimeMonths: number;
  status: 'planned' | 'in_progress' | 'completed';
  adoptionPercent: number; // 0 - 100
}

export interface CSRDDisclosureSection {
  id: string;
  code: string;
  title: string;
  esrsTopic: 'ESRS E1 Climate Change';
  description: string;
  metricValue: string;
  unit: string;
  baselineYearValue: string;
  progressStatus: 'Compliant' | 'Ready for Limited Assurance' | 'In Progress';
  mandatoryUnderCsrd: boolean;
  regulatoryReference: string;
  narrativeDraft: string;
  linkedScope: string;
}

export interface EmissionFactor {
  id: string;
  name: string;
  category: string;
  unit: string;
  factorKgCO2e: number;
  source: string;
  region: string;
  year: number;
  uncertaintyPercent: number;
}

export interface EmissionsSummary {
  scope1Tons: number;
  scope2LocationBasedTons: number;
  scope2MarketBasedTons: number;
  scope3Tons: number;
  totalGrossLocationTons: number;
  totalGrossMarketTons: number;
  retiredDurableRemovalsTons: number;
  retiredAvoidanceOffsetsTons: number;
  netMarketTons: number;
  energyTotalMWh: number;
  renewableEnergyMWh: number;
  renewableEnergyPercent: number;
  intensityPerSqM: number;
  intensityPerMRevenue: number;
}
