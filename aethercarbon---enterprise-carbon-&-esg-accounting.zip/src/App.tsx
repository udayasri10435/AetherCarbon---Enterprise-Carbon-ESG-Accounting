/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  ActivityRecord, 
  Facility, 
  CarbonOffset, 
  EACCertificate, 
  CSRDDisclosureSection, 
  DecarbonizationLever,
  AuditVerificationStatus 
} from './types/carbon';
import { 
  SEED_FACILITIES, 
  SEED_ACTIVITY_RECORDS, 
  SEED_OFFSETS, 
  SEED_EACS, 
  SEED_CSRD_DISCLOSURES, 
  SEED_DECARBONIZATION_LEVERS 
} from './data/seedData';
import { computeEmissionsSummary } from './utils/carbonEngine';
import { detectLedgerAnomalies } from './utils/aiCopilot';
import { TopBar } from './components/TopBar';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { EmissionsLedger } from './components/EmissionsLedger';
import { CsrdReportingView } from './components/CsrdReportingView';
import { OffsetsEacView } from './components/OffsetsEacView';
import { DecarbonizationPathwaysView } from './components/DecarbonizationPathwaysView';
import { RegulatoryHubView } from './components/RegulatoryHubView';
import { LogActivityModal } from './components/LogActivityModal';
import { AuditExportModal } from './components/AuditExportModal';
import { ClimateCopilotModal } from './components/ClimateCopilotModal';

export default function App() {
  // State with LocalStorage persistence fallback
  const [facilities, setFacilities] = useState<Facility[]>(() => {
    const saved = localStorage.getItem('aether_facilities');
    return saved ? JSON.parse(saved) : SEED_FACILITIES;
  });

  const [records, setRecords] = useState<ActivityRecord[]>(() => {
    const saved = localStorage.getItem('aether_records');
    return saved ? JSON.parse(saved) : SEED_ACTIVITY_RECORDS;
  });

  const [offsets, setOffsets] = useState<CarbonOffset[]>(() => {
    const saved = localStorage.getItem('aether_offsets');
    return saved ? JSON.parse(saved) : SEED_OFFSETS;
  });

  const [eacs, setEacs] = useState<EACCertificate[]>(() => {
    const saved = localStorage.getItem('aether_eacs');
    return saved ? JSON.parse(saved) : SEED_EACS;
  });

  const [disclosures, setDisclosures] = useState<CSRDDisclosureSection[]>(() => {
    const saved = localStorage.getItem('aether_disclosures');
    return saved ? JSON.parse(saved) : SEED_CSRD_DISCLOSURES;
  });

  const [levers, setLevers] = useState<DecarbonizationLever[]>(() => {
    const saved = localStorage.getItem('aether_levers');
    return saved ? JSON.parse(saved) : SEED_DECARBONIZATION_LEVERS;
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isLogModalOpen, setIsLogModalOpen] = useState<boolean>(false);
  const [isAuditExportOpen, setIsAuditExportOpen] = useState<boolean>(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('aether_records', JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem('aether_offsets', JSON.stringify(offsets));
  }, [offsets]);

  useEffect(() => {
    localStorage.setItem('aether_eacs', JSON.stringify(eacs));
  }, [eacs]);

  useEffect(() => {
    localStorage.setItem('aether_disclosures', JSON.stringify(disclosures));
  }, [disclosures]);

  useEffect(() => {
    localStorage.setItem('aether_levers', JSON.stringify(levers));
  }, [levers]);

  // Recalculate consolidated metrics in real-time
  const summary = useMemo(() => {
    return computeEmissionsSummary(records, facilities, offsets, eacs);
  }, [records, facilities, offsets, eacs]);

  // Run audit pre-flight anomaly checks
  const anomalies = useMemo(() => {
    return detectLedgerAnomalies(records);
  }, [records]);

  // Audit verified percentage
  const verifiedPercent = useMemo(() => {
    if (records.length === 0) return 100;
    const verified = records.filter(r => r.verificationStatus === 'auditor_verified').length;
    return Math.round((verified / records.length) * 100);
  }, [records]);

  // Handlers
  const handleAddRecord = (record: ActivityRecord) => {
    setRecords(prev => [record, ...prev]);
  };

  const handleUpdateRecordStatus = (recordId: string, status: AuditVerificationStatus, notes?: string) => {
    setRecords(prev => prev.map(r => {
      if (r.id === recordId) {
        return {
          ...r,
          verificationStatus: status,
          auditorNotes: notes !== undefined ? notes : r.auditorNotes
        };
      }
      return r;
    }));
  };

  const handleDeleteRecord = (recordId: string) => {
    setRecords(prev => prev.filter(r => r.id !== recordId));
  };

  const handleRetireOffset = (offsetId: string) => {
    setOffsets(prev => prev.map(o => {
      if (o.id === offsetId) {
        return {
          ...o,
          status: 'retired_for_reporting',
          retirementDate: new Date().toISOString().split('T')[0],
          beneficiaryEntity: 'Apex Global Technologies & Logistics Inc. (CSRD FY2026)'
        };
      }
      return o;
    }));
  };

  const handleAddOffset = (newOffset: CarbonOffset) => {
    setOffsets(prev => [newOffset, ...prev]);
  };

  const handleAddEAC = (newEac: EACCertificate) => {
    setEacs(prev => [newEac, ...prev]);
  };

  const handleUpdateDisclosureNarrative = (id: string, narrative: string) => {
    setDisclosures(prev => prev.map(d => {
      if (d.id === id) {
        return { ...d, narrativeDraft: narrative };
      }
      return d;
    }));
  };

  const handleUpdateLeverAdoption = (leverId: string, adoptionPercent: number) => {
    setLevers(prev => prev.map(l => {
      if (l.id === leverId) {
        return { ...l, adoptionPercent };
      }
      return l;
    }));
  };

  const handleResetToSeedData = () => {
    if (confirm('Reset platform data to factory enterprise seed state?')) {
      localStorage.clear();
      setRecords(SEED_ACTIVITY_RECORDS);
      setFacilities(SEED_FACILITIES);
      setOffsets(SEED_OFFSETS);
      setEacs(SEED_EACS);
      setDisclosures(SEED_CSRD_DISCLOSURES);
      setLevers(SEED_DECARBONIZATION_LEVERS);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-neutral-950">
      {/* Top Bar with 3-Zone Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenLogModal={() => setIsLogModalOpen(true)}
        onOpenAuditExport={() => setIsAuditExportOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        verifiedPercent={verifiedPercent}
      />

      {/* Main Content Canvas (Desktop Baseline 1440px container, single elevation) */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'dashboard' && (
          <ExecutiveDashboard
            summary={summary}
            facilities={facilities}
            records={records}
            offsets={offsets}
            eacs={eacs}
            onNavigateToTab={setActiveTab}
            onOpenLogModal={() => setIsLogModalOpen(true)}
            anomalies={anomalies}
          />
        )}

        {activeTab === 'ledger' && (
          <EmissionsLedger
            records={records}
            facilities={facilities}
            onOpenLogModal={() => setIsLogModalOpen(true)}
            onUpdateRecordStatus={handleUpdateRecordStatus}
            onDeleteRecord={handleDeleteRecord}
          />
        )}

        {activeTab === 'csrd' && (
          <CsrdReportingView
            disclosures={disclosures}
            summary={summary}
            records={records}
            offsets={offsets}
            eacs={eacs}
            onUpdateDisclosureNarrative={handleUpdateDisclosureNarrative}
            onOpenAuditExport={() => setIsAuditExportOpen(true)}
          />
        )}

        {activeTab === 'offsets' && (
          <OffsetsEacView
            offsets={offsets}
            eacs={eacs}
            summary={summary}
            onRetireOffset={handleRetireOffset}
            onAddOffset={handleAddOffset}
            onAddEAC={handleAddEAC}
          />
        )}

        {activeTab === 'pathways' && (
          <DecarbonizationPathwaysView
            levers={levers}
            summary={summary}
            onUpdateLeverAdoption={handleUpdateLeverAdoption}
          />
        )}

        {activeTab === 'regulatory' && (
          <RegulatoryHubView
            summary={summary}
            onOpenAuditExport={() => setIsAuditExportOpen(true)}
            onNavigateToTab={setActiveTab}
          />
        )}
      </main>

      {/* Subtle, unboxed footer with real actions */}
      <footer className="w-full max-w-7xl mx-auto px-6 py-6 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-3">
        <div className="flex items-center gap-2">
          <span>AetherCarbon Platform</span>
          <span aria-hidden="true">·</span>
          <span>GHG Protocol Corporate Standard & ESRS E1 Aligned</span>
          <span aria-hidden="true">·</span>
          <span>ISAE 3000 Pre-Audit</span>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={handleResetToSeedData}
            className="text-neutral-500 hover:text-neutral-300 transition-colors"
          >
            Reset Seed Data
          </button>
          <span>© {new Date().getFullYear()} Apex Global Technologies Inc.</span>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <LogActivityModal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        facilities={facilities}
        onAddRecord={handleAddRecord}
      />

      <AuditExportModal
        isOpen={isAuditExportOpen}
        onClose={() => setIsAuditExportOpen(false)}
        summary={summary}
        records={records}
        facilities={facilities}
        offsets={offsets}
        eacs={eacs}
        disclosures={disclosures}
      />

      <ClimateCopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        summary={summary}
        records={records}
        onNavigateToTab={(tab) => {
          setActiveTab(tab);
          setIsCopilotOpen(false);
        }}
        onOpenAuditExport={() => {
          setIsAuditExportOpen(true);
          setIsCopilotOpen(false);
        }}
      />
    </div>
  );
}
