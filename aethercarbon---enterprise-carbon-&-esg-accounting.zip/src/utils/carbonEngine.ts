import { EmissionFactor, ActivityRecord, Facility, CarbonOffset, EACCertificate, EmissionsSummary } from '../types/carbon';

export const EMISSION_FACTOR_CATALOG: EmissionFactor[] = [
  // Scope 1: Stationary Combustion
  {
    id: 'ef_natgas_therms',
    name: 'Natural Gas (Pipeline)',
    category: 'stationary_combustion',
    unit: 'therms',
    factorKgCO2e: 5.306, // EPA GHG Hub 2024
    source: 'EPA GHG Hub 2024',
    region: 'North America / Global',
    year: 2024,
    uncertaintyPercent: 2.5
  },
  {
    id: 'ef_natgas_mwh',
    name: 'Natural Gas (High Calorific)',
    category: 'stationary_combustion',
    unit: 'MWh',
    factorKgCO2e: 202.28, // DEFRA 2024
    source: 'DEFRA 2024',
    region: 'Europe / UK',
    year: 2024,
    uncertaintyPercent: 3.0
  },
  {
    id: 'ef_diesel_stationary',
    name: 'Diesel Fuel (Backup Power Gen)',
    category: 'stationary_combustion',
    unit: 'liters',
    factorKgCO2e: 2.687,
    source: 'DEFRA 2024',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 3.5
  },
  {
    id: 'ef_lpg_kg',
    name: 'Liquefied Petroleum Gas (LPG)',
    category: 'stationary_combustion',
    unit: 'kg',
    factorKgCO2e: 2.939,
    source: 'EPA GHG Hub 2024',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 3.0
  },

  // Scope 1: Mobile Combustion
  {
    id: 'ef_fleet_diesel',
    name: 'Commercial Diesel Fleet (Euro VI)',
    category: 'mobile_combustion',
    unit: 'liters',
    factorKgCO2e: 2.705,
    source: 'DEFRA 2024',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 4.0
  },
  {
    id: 'ef_fleet_gasoline',
    name: 'Motor Gasoline (Fleet Cars & Vans)',
    category: 'mobile_combustion',
    unit: 'liters',
    factorKgCO2e: 2.314,
    source: 'EPA GHG Hub 2024',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 4.0
  },
  {
    id: 'ef_jetfuel_liters',
    name: 'Aviation Kerosene (Corporate Jet)',
    category: 'mobile_combustion',
    unit: 'liters',
    factorKgCO2e: 2.541,
    source: 'ICAO / DEFRA 2024',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 5.0
  },

  // Scope 1: Fugitive Emissions (Refrigerants GWP)
  {
    id: 'ef_refrig_r410a',
    name: 'Refrigerant R-410A (HVAC Leakage)',
    category: 'fugitive_refrigerants',
    unit: 'kg',
    factorKgCO2e: 2088.0, // IPCC AR4 GWP
    source: 'IPCC AR4 / EPA',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 2.0
  },
  {
    id: 'ef_refrig_r134a',
    name: 'Refrigerant R-134a (Chiller Gas)',
    category: 'fugitive_refrigerants',
    unit: 'kg',
    factorKgCO2e: 1430.0, // IPCC AR4 GWP
    source: 'IPCC AR4',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 2.0
  },

  // Scope 2: Purchased Electricity (Location-based grid emissions)
  {
    id: 'ef_grid_us_wecc',
    name: 'US Grid Electricity (eGRID CAMX/WECC)',
    category: 'purchased_electricity',
    unit: 'kWh',
    factorKgCO2e: 0.218, // 218 gCO2e/kWh
    source: 'EPA eGRID 2024',
    region: 'USA - California',
    year: 2024,
    uncertaintyPercent: 4.5
  },
  {
    id: 'ef_grid_germany',
    name: 'German Grid Electricity (UBA Mix)',
    category: 'purchased_electricity',
    unit: 'kWh',
    factorKgCO2e: 0.380, // German federal environment agency 380 gCO2e/kWh
    source: 'UBA Germany / IEA 2024',
    region: 'Germany / EU',
    year: 2024,
    uncertaintyPercent: 4.0
  },
  {
    id: 'ef_grid_netherlands',
    name: 'Netherlands Grid Electricity (Residual Mix)',
    category: 'purchased_electricity',
    unit: 'kWh',
    factorKgCO2e: 0.328,
    source: 'AIB / IEA 2024',
    region: 'Netherlands',
    year: 2024,
    uncertaintyPercent: 5.0
  },
  {
    id: 'ef_grid_japan_tepco',
    name: 'Japan Grid Electricity (TEPCO Area)',
    category: 'purchased_electricity',
    unit: 'kWh',
    factorKgCO2e: 0.441,
    source: 'METI / IEA 2024',
    region: 'Japan',
    year: 2024,
    uncertaintyPercent: 4.0
  },
  {
    id: 'ef_district_heating',
    name: 'District Steam & Municipal Heating',
    category: 'district_heating',
    unit: 'MWh',
    factorKgCO2e: 172.5,
    source: 'Euroheat / DEFRA 2024',
    region: 'EU / UK',
    year: 2024,
    uncertaintyPercent: 6.0
  },

  // Scope 3: Value Chain
  {
    id: 'ef_s3_cloud_compute',
    name: 'Cloud Infrastructure (AWS/GCP Dedicated vCPU-hr)',
    category: 'cat_1_purchased_goods',
    unit: 'vCPU-hours',
    factorKgCO2e: 0.0032,
    source: 'Cloud Carbon Footprint / CCF',
    region: 'Global Hyperscale',
    year: 2024,
    uncertaintyPercent: 8.0
  },
  {
    id: 'ef_s3_semiconductors_spend',
    name: 'Electronic Components & Hardware (Spend)',
    category: 'cat_1_purchased_goods',
    unit: 'USD',
    factorKgCO2e: 0.345, // 0.345 kgCO2e per USD spend
    source: 'EXIOBASE v3.8 / EEIO',
    region: 'Global Supply Chain',
    year: 2024,
    uncertaintyPercent: 12.0
  },
  {
    id: 'ef_s3_air_travel_longhaul',
    name: 'Business Air Travel (Long Haul with Radiative Forcing)',
    category: 'cat_6_business_travel',
    unit: 'passenger-km',
    factorKgCO2e: 0.193,
    source: 'DEFRA 2024',
    region: 'International',
    year: 2024,
    uncertaintyPercent: 5.0
  },
  {
    id: 'ef_s3_air_travel_shorthaul',
    name: 'Business Air Travel (Short Haul Domestic)',
    category: 'cat_6_business_travel',
    unit: 'passenger-km',
    factorKgCO2e: 0.245,
    source: 'DEFRA 2024',
    region: 'Regional',
    year: 2024,
    uncertaintyPercent: 6.0
  },
  {
    id: 'ef_s3_ocean_freight',
    name: 'Ocean Container Freight (TEU-km)',
    category: 'cat_4_upstream_transport',
    unit: 'ton-km',
    factorKgCO2e: 0.016,
    source: 'IMO / DEFRA 2024',
    region: 'Maritime Global',
    year: 2024,
    uncertaintyPercent: 7.0
  },
  {
    id: 'ef_s3_employee_commute',
    name: 'Employee Commuting (Average Mix Car/Transit)',
    category: 'cat_7_employee_commuting',
    unit: 'commute-days',
    factorKgCO2e: 4.82,
    source: 'DEFRA 2024 / Quantis',
    region: 'OECD',
    year: 2024,
    uncertaintyPercent: 9.0
  },
  {
    id: 'ef_s3_waste_landfill',
    name: 'Commercial Mixed Municipal Waste (Landfill)',
    category: 'cat_5_waste_operations',
    unit: 'metric_tons',
    factorKgCO2e: 586.2,
    source: 'EPA WARM v15',
    region: 'Global',
    year: 2024,
    uncertaintyPercent: 10.0
  }
];

export function calculateRecordEmissions(
  quantity: number,
  factorValueKgCO2e: number,
  marketBasedDeductionTons: number = 0
): number {
  // Convert kgCO2e to metric tons (tCO2e)
  const grossTons = (quantity * factorValueKgCO2e) / 1000;
  const netTons = Math.max(0, grossTons - marketBasedDeductionTons);
  return Number(netTons.toFixed(3));
}

export type { EmissionsSummary };

export function computeEmissionsSummary(
  records: ActivityRecord[],
  facilities: Facility[],
  offsets: CarbonOffset[],
  eacs: EACCertificate[]
): EmissionsSummary {
  let s1 = 0;
  let s2Location = 0;
  let s2Market = 0;
  let s3 = 0;
  let totalEnergyMWh = 0;

  for (const r of records) {
    if (r.scope === 'scope_1') {
      s1 += r.calculatedEmissionsTons;
      // Convert natural gas/fuel MWh if applicable
      if (r.unit === 'MWh') totalEnergyMWh += r.quantity;
      else if (r.unit === 'therms') totalEnergyMWh += r.quantity * 0.0293;
    } else if (r.scope === 'scope_2') {
      s2Location += r.calculatedEmissionsTons;
      const deduction = r.marketBasedDeductionTons || 0;
      s2Market += Math.max(0, r.calculatedEmissionsTons - deduction);

      if (r.unit === 'kWh') totalEnergyMWh += r.quantity / 1000;
      else if (r.unit === 'MWh') totalEnergyMWh += r.quantity;
    } else if (r.scope === 'scope_3') {
      s3 += r.calculatedEmissionsTons;
    }
  }

  // Calculate EAC retired volume in MWh
  const totalEacMWh = eacs
    .filter(e => e.status === 'retired')
    .reduce((sum, e) => sum + e.volumeMWh, 0);

  // Facility floor area & revenue totals
  const totalFloorArea = facilities.reduce((sum, f) => sum + f.floorAreaSqM, 0);
  const totalRevenueM = facilities.reduce((sum, f) => sum + f.annualRevenueUsdM, 0);

  // Carbon Offsets retired
  const retiredDurable = offsets
    .filter(o => o.status === 'retired_for_reporting' && o.removalType === 'durable_removal')
    .reduce((sum, o) => sum + o.quantityTons, 0);

  const retiredAvoidance = offsets
    .filter(o => o.status === 'retired_for_reporting' && o.removalType === 'avoidance')
    .reduce((sum, o) => sum + o.quantityTons, 0);

  const grossLocation = s1 + s2Location + s3;
  const grossMarket = s1 + s2Market + s3;
  // According to SBTi and Oxford Principles, only durable removals can officially net against residual emissions for Net-Zero claims
  const netMarket = Math.max(0, grossMarket - retiredDurable - retiredAvoidance);

  // Estimate renewable portion
  const renewableEnergyMWh = Math.min(totalEnergyMWh, totalEacMWh + (totalEnergyMWh * 0.28)); // 28% grid baseline + EACs
  const renewablePercent = totalEnergyMWh > 0 ? Math.min(100, (renewableEnergyMWh / totalEnergyMWh) * 100) : 0;

  return {
    scope1Tons: Number(s1.toFixed(2)),
    scope2LocationBasedTons: Number(s2Location.toFixed(2)),
    scope2MarketBasedTons: Number(s2Market.toFixed(2)),
    scope3Tons: Number(s3.toFixed(2)),
    totalGrossLocationTons: Number(grossLocation.toFixed(2)),
    totalGrossMarketTons: Number(grossMarket.toFixed(2)),
    retiredDurableRemovalsTons: Number(retiredDurable.toFixed(2)),
    retiredAvoidanceOffsetsTons: Number(retiredAvoidance.toFixed(2)),
    netMarketTons: Number(netMarket.toFixed(2)),
    energyTotalMWh: Number(totalEnergyMWh.toFixed(1)),
    renewableEnergyMWh: Number(renewableEnergyMWh.toFixed(1)),
    renewableEnergyPercent: Number(renewablePercent.toFixed(1)),
    intensityPerSqM: totalFloorArea > 0 ? Number((grossMarket / totalFloorArea * 1000).toFixed(2)) : 0, // kgCO2e/m2
    intensityPerMRevenue: totalRevenueM > 0 ? Number((grossMarket / totalRevenueM).toFixed(2)) : 0 // tCO2e/$M
  };
}

export function formatTons(tons: number): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1
  }).format(tons) + ' tCO₂e';
}

export function formatNumber(num: number, decimals: number = 0): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(num);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(amount);
}
