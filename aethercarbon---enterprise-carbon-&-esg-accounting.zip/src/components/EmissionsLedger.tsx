import React, { useState, useMemo } from 'react';
import { 
  ActivityRecord, 
  EmissionScope, 
  Facility, 
  AuditVerificationStatus 
} from '../types/carbon';
import { 
  formatTons, 
  formatNumber, 
  formatCurrency 
} from '../utils/carbonEngine';
import { 
  Search, 
  Filter, 
  Plus, 
  Download, 
  CheckCircle, 
  Clock, 
  FileText, 
  X, 
  ExternalLink, 
  ChevronRight, 
  AlertCircle,
  Shield,
  Trash2,
  Check
} from 'lucide-react';

interface EmissionsLedgerProps {
  records: ActivityRecord[];
  facilities: Facility[];
  onOpenLogModal: () => void;
  onUpdateRecordStatus: (recordId: string, status: AuditVerificationStatus, notes?: string) => void;
  onDeleteRecord: (recordId: string) => void;
}

export const EmissionsLedger: React.FC<EmissionsLedgerProps> = ({
  records,
  facilities,
  onOpenLogModal,
  onUpdateRecordStatus,
  onDeleteRecord
}) => {
  const [selectedScope, setSelectedScope] = useState<string>('all');
  const [selectedFacility, setSelectedFacility] = useState<string>('all');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [inspectingRecord, setInspectingRecord] = useState<ActivityRecord | null>(null);
  const [auditorNoteInput, setAuditorNoteInput] = useState<string>('');
  const [showExportSuccess, setShowExportSuccess] = useState<boolean>(false);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      if (selectedScope !== 'all' && r.scope !== selectedScope) return false;
      if (selectedFacility !== 'all' && r.facilityId !== selectedFacility) return false;
      if (selectedTier !== 'all' && !r.dataQualityTier.includes(selectedTier)) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchName = r.activityName.toLowerCase().includes(q);
        const matchFacility = r.facilityName.toLowerCase().includes(q);
        const matchCategory = r.categoryLabel.toLowerCase().includes(q);
        const matchDoc = (r.evidenceDocName || '').toLowerCase().includes(q);
        const matchFactor = r.factorSource.toLowerCase().includes(q);
        if (!matchName && !matchFacility && !matchCategory && !matchDoc && !matchFactor) {
          return false;
        }
      }
      return true;
    });
  }, [records, selectedScope, selectedFacility, selectedTier, searchQuery]);

  // Aggregate totals for the filtered subset
  const filteredTotalTons = useMemo(() => {
    return filteredRecords.reduce((sum, r) => sum + r.calculatedEmissionsTons, 0);
  }, [filteredRecords]);

  const handleOpenInspector = (record: ActivityRecord) => {
    setInspectingRecord(record);
    setAuditorNoteInput(record.auditorNotes || '');
  };

  const handleSaveAuditorNote = () => {
    if (!inspectingRecord) return;
    onUpdateRecordStatus(inspectingRecord.id, inspectingRecord.verificationStatus, auditorNoteInput);
    setInspectingRecord({ ...inspectingRecord, auditorNotes: auditorNoteInput });
  };

  const handleSetVerificationStatus = (status: AuditVerificationStatus) => {
    if (!inspectingRecord) return;
    onUpdateRecordStatus(inspectingRecord.id, status, auditorNoteInput);
    setInspectingRecord({ ...inspectingRecord, verificationStatus: status });
  };

  const handleExportCsv = () => {
    const headers = [
      'ID',
      'Date',
      'Facility',
      'Scope',
      'Category',
      'Activity Name',
      'Quantity',
      'Unit',
      'Emission Factor (kgCO2e/unit)',
      'Factor Source',
      'Calculated Emissions (tCO2e)',
      'Data Quality Tier',
      'Verification Status',
      'Evidence Document',
      'Auditor Notes'
    ];

    const rows = filteredRecords.map(r => [
      r.id,
      r.date,
      `"${r.facilityName}"`,
      r.scope.toUpperCase(),
      `"${r.categoryLabel}"`,
      `"${r.activityName}"`,
      r.quantity,
      r.unit,
      r.emissionFactorValue,
      `"${r.factorSource}"`,
      r.calculatedEmissionsTons,
      `"${r.dataQualityTier}"`,
      r.verificationStatus,
      `"${r.evidenceDocName || ''}"`,
      `"${r.auditorNotes || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `AetherCarbon_Emissions_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setShowExportSuccess(true);
    setTimeout(() => setShowExportSuccess(false), 3000);
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight">Emissions Activity Ledger</h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Audit-ready granular ledger of operational and value-chain greenhouse gas emissions (GHG Protocol Corporate Standard)
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {showExportSuccess && (
            <span className="text-xs text-emerald-400 flex items-center gap-1 font-mono">
              <Check className="w-3.5 h-3.5" /> CSV Exported
            </span>
          )}

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-900 border border-neutral-800 rounded-md hover:bg-neutral-800 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onOpenLogModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Activity / Bill</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        {/* Scope Tabs (interactive button segmented control) */}
        <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-md overflow-x-auto">
          {[
            { id: 'all', label: 'All Scopes' },
            { id: 'scope_1', label: 'Scope 1 (Direct)' },
            { id: 'scope_2', label: 'Scope 2 (Electricity)' },
            { id: 'scope_3', label: 'Scope 3 (Value Chain)' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedScope(tab.id)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                selectedScope === tab.id
                  ? 'bg-neutral-800 text-white font-semibold'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Secondary Dropdowns & Search */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Facility Filter */}
          <select
            value={selectedFacility}
            onChange={(e) => setSelectedFacility(e.target.value)}
            className="px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-300 text-xs focus:outline-none focus:border-neutral-700"
          >
            <option value="all">All Facilities (4)</option>
            {facilities.map((f) => (
              <option key={f.id} value={f.id}>{f.name}</option>
            ))}
          </select>

          {/* Data Quality Tier Filter */}
          <select
            value={selectedTier}
            onChange={(e) => setSelectedTier(e.target.value)}
            className="px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-300 text-xs focus:outline-none focus:border-neutral-700"
          >
            <option value="all">All Quality Tiers</option>
            <option value="Tier 1">Tier 1 (Metered / Primary)</option>
            <option value="Tier 2">Tier 2 (Fuel-Specific)</option>
            <option value="Tier 3">Tier 3 (Spend Proxy)</option>
          </select>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search activities, docs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 text-xs placeholder-neutral-500 focus:outline-none focus:border-neutral-700 w-48 sm:w-56"
            />
          </div>
        </div>
      </div>

      {/* Ledger Table (High-density, flat border, tabular nums) */}
      <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-800 bg-neutral-950 text-neutral-400 font-medium">
                <th className="py-2.5 px-4">Date</th>
                <th className="py-2.5 px-3">Scope & Category</th>
                <th className="py-2.5 px-3">Activity Description</th>
                <th className="py-2.5 px-3">Facility</th>
                <th className="py-2.5 px-3 text-right">Activity Volume</th>
                <th className="py-2.5 px-3 text-right">Emission Factor</th>
                <th className="py-2.5 px-4 text-right">Gross (tCO₂e)</th>
                <th className="py-2.5 px-3 text-center">Quality Tier</th>
                <th className="py-2.5 px-3 text-center">Audit Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-neutral-500 text-xs">
                    No emissions records match your selected filters. Click "Log Activity" to add one.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => {
                  const isVerified = r.verificationStatus === 'auditor_verified';
                  const isReady = r.verificationStatus === 'ready_for_audit';
                  const isScope1 = r.scope === 'scope_1';
                  const isScope2 = r.scope === 'scope_2';

                  return (
                    <tr 
                      key={r.id} 
                      onClick={() => handleOpenInspector(r)}
                      className="hover:bg-neutral-800/40 cursor-pointer transition-colors group"
                    >
                      <td className="py-2.5 px-4 font-mono text-neutral-400 tabular-nums whitespace-nowrap">
                        {r.date}
                      </td>

                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className={`text-[11px] font-semibold uppercase ${
                          isScope1 ? 'text-amber-400' : isScope2 ? 'text-sky-400' : 'text-purple-400'
                        }`}>
                          {r.scope.replace('_', ' ')}
                        </span>
                        <div className="text-[11px] text-neutral-400 truncate max-w-[160px]">
                          {r.categoryLabel}
                        </div>
                      </td>

                      <td className="py-2.5 px-3">
                        <div className="font-medium text-white truncate max-w-[260px]">
                          {r.activityName}
                        </div>
                        {r.evidenceDocName && (
                          <div className="text-[11px] text-neutral-400 flex items-center gap-1 mt-0.5 truncate max-w-[240px]">
                            <FileText className="w-3 h-3 text-neutral-400" />
                            <span>{r.evidenceDocName}</span>
                          </div>
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-neutral-300 whitespace-nowrap truncate max-w-[150px]">
                        {r.facilityName}
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-neutral-200 whitespace-nowrap">
                        {formatNumber(r.quantity, 0)} <span className="text-[11px] text-neutral-400">{r.unit}</span>
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-neutral-400 whitespace-nowrap text-[11px]">
                        {r.emissionFactorValue} <span className="text-neutral-400">{r.emissionFactorUnit}</span>
                      </td>

                      <td className="py-2.5 px-4 text-right font-mono tabular-nums font-bold text-white whitespace-nowrap">
                        {formatNumber(r.calculatedEmissionsTons, 3)}
                      </td>

                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <span className="text-[11px] text-neutral-400">
                          {r.dataQualityTier.split(' ')[0]} {r.dataQualityTier.split(' ')[1]}
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        {isVerified ? (
                          <span className="text-[11px] text-emerald-400 font-medium inline-flex items-center gap-1">
                            <CheckCircle className="w-3 h-3" /> Verified
                          </span>
                        ) : isReady ? (
                          <span className="text-[11px] text-sky-400 font-medium inline-flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Audit Ready
                          </span>
                        ) : (
                          <span className="text-[11px] text-amber-400 font-medium inline-flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" /> Draft Review
                          </span>
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenInspector(r);
                          }}
                          className="p-1 text-neutral-400 hover:text-white transition-colors"
                          title="Inspect Audit Proof"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Ledger Bottom Summary Bar */}
        <div className="py-2.5 px-4 bg-neutral-950 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-2">
          <div>
            Showing <strong className="text-neutral-200 font-mono">{filteredRecords.length}</strong> activity records in active view
          </div>
          <div className="flex items-center gap-4">
            <span>
              Filtered Subtotal: <strong className="text-white font-mono">{formatNumber(filteredTotalTons, 2)} tCO₂e</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Audit Inspector Drawer / Detail Overlay */}
      {inspectingRecord && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-lg bg-neutral-950 border-l border-neutral-800 h-full overflow-y-auto p-6 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div className="space-y-6">
              {/* Drawer Top */}
              <div className="flex items-start justify-between pb-4 border-b border-neutral-800">
                <div>
                  <div className="flex items-center gap-2 text-xs text-neutral-400">
                    <span className="font-mono text-emerald-400 uppercase font-semibold">
                      {inspectingRecord.scope.replace('_', ' ')}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{inspectingRecord.id}</span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-1">
                    {inspectingRecord.activityName}
                  </h3>
                </div>
                <button
                  onClick={() => setInspectingRecord(null)}
                  className="p-1 text-neutral-400 hover:text-white rounded"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Emissions Calculation Formula Breakdown */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg space-y-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Audit Calculation Breakdown
                </span>

                <div className="p-3 bg-neutral-950 rounded border border-neutral-800 font-mono text-xs space-y-1.5">
                  <div className="text-neutral-400">
                    Formula: <span className="text-neutral-200">Activity Data × Emission Factor ÷ 1,000</span>
                  </div>
                  <div className="text-emerald-400 pt-1 border-t border-neutral-800">
                    {formatNumber(inspectingRecord.quantity, 0)} {inspectingRecord.unit} × {inspectingRecord.emissionFactorValue} kgCO₂e/{inspectingRecord.unit}
                    {' '}= <strong className="text-white text-sm">{formatNumber(inspectingRecord.calculatedEmissionsTons, 3)} tCO₂e</strong>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                  <div>
                    <span className="text-neutral-500">Emission Factor Source:</span>
                    <div className="text-neutral-200 font-medium">{inspectingRecord.factorSource}</div>
                  </div>
                  <div>
                    <span className="text-neutral-500">Facility Location:</span>
                    <div className="text-neutral-200 font-medium">{inspectingRecord.facilityName}</div>
                  </div>
                </div>
              </div>

              {/* Data Quality & Assurance Metadata */}
              <div className="space-y-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Data Quality & Assurance Tier
                </span>
                
                <div className="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Quality Classification:</span>
                    <span className="font-semibold text-neutral-200">{inspectingRecord.dataQualityTier}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">GHG Protocol Standard:</span>
                    <span className="text-neutral-200">Corporate Standard (Revised)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Assurance Standard:</span>
                    <span className="text-neutral-200">ISAE 3000 (Revised) Limited Assurance</span>
                  </div>
                </div>
              </div>

              {/* Attached Evidence Document */}
              <div className="space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Primary Evidence Document
                </span>
                
                {inspectingRecord.evidenceDocName ? (
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-emerald-400" />
                      <div>
                        <div className="font-medium text-white">{inspectingRecord.evidenceDocName}</div>
                        <div className="text-[11px] text-neutral-400">Calibrated meter logs / utility invoice receipt</div>
                      </div>
                    </div>
                    <span className="text-emerald-400 text-[11px] font-mono">Archived</span>
                  </div>
                ) : (
                  <div className="p-3 bg-neutral-900 border border-dashed border-neutral-800 rounded-lg text-xs text-neutral-400 text-center">
                    No primary PDF attached. Spend ledger entry.
                  </div>
                )}
              </div>

              {/* Auditor Review Notes */}
              <div className="space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Auditor Working Paper Notes
                </span>
                <textarea
                  rows={3}
                  value={auditorNoteInput}
                  onChange={(e) => setAuditorNoteInput(e.target.value)}
                  placeholder="Record auditor inquiries, sampling notes, or cross-check verification details..."
                  className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-md text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-neutral-700"
                />
                <div className="flex justify-end">
                  <button
                    onClick={handleSaveAuditorNote}
                    className="px-2.5 py-1 text-xs text-neutral-300 bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
                  >
                    Save Notes
                  </button>
                </div>
              </div>

              {/* Verification Status Selector */}
              <div className="space-y-2 pt-2 border-t border-neutral-800">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Update Verification Status
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleSetVerificationStatus('auditor_verified')}
                    className={`py-2 px-2 text-xs font-medium rounded border transition-colors ${
                      inspectingRecord.verificationStatus === 'auditor_verified'
                        ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    Auditor Verified
                  </button>
                  <button
                    onClick={() => handleSetVerificationStatus('ready_for_audit')}
                    className={`py-2 px-2 text-xs font-medium rounded border transition-colors ${
                      inspectingRecord.verificationStatus === 'ready_for_audit'
                        ? 'bg-sky-950 border-sky-600 text-sky-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    Ready for Audit
                  </button>
                  <button
                    onClick={() => handleSetVerificationStatus('draft_review')}
                    className={`py-2 px-2 text-xs font-medium rounded border transition-colors ${
                      inspectingRecord.verificationStatus === 'draft_review'
                        ? 'bg-amber-950 border-amber-600 text-amber-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    Draft Review
                  </button>
                </div>
              </div>
            </div>

            {/* Drawer Bottom Actions */}
            <div className="pt-6 border-t border-neutral-800 flex items-center justify-between">
              <button
                onClick={() => {
                  if (confirm(`Are you sure you want to remove activity record "${inspectingRecord.activityName}"?`)) {
                    onDeleteRecord(inspectingRecord.id);
                    setInspectingRecord(null);
                  }
                }}
                className="flex items-center gap-1 text-xs text-rose-400 hover:text-rose-300"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Record</span>
              </button>

              <button
                onClick={() => setInspectingRecord(null)}
                className="px-4 py-1.5 text-xs font-medium text-white bg-neutral-800 hover:bg-neutral-700 rounded-md transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
