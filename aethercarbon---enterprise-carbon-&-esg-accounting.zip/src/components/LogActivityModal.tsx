import React, { useState, useEffect } from 'react';
import { 
  Facility, 
  ActivityRecord, 
  EmissionScope, 
  Scope1Category, 
  Scope2Category, 
  Scope3Category, 
  DataQualityTier 
} from '../types/carbon';
import { 
  EMISSION_FACTOR_CATALOG, 
  calculateRecordEmissions, 
  formatNumber, 
  formatTons 
} from '../utils/carbonEngine';
import { X, Calculator, Upload, Zap, Check } from 'lucide-react';

interface LogActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  facilities: Facility[];
  onAddRecord: (record: ActivityRecord) => void;
}

export const LogActivityModal: React.FC<LogActivityModalProps> = ({
  isOpen,
  onClose,
  facilities,
  onAddRecord
}) => {
  if (!isOpen) return null;

  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [facilityId, setFacilityId] = useState<string>(facilities[0]?.id || '');
  const [scope, setScope] = useState<EmissionScope>('scope_1');
  const [selectedFactorId, setSelectedFactorId] = useState<string>('ef_natgas_therms');
  const [activityName, setActivityName] = useState<string>('Quarterly Natural Gas Utility Consumption');
  const [quantity, setQuantity] = useState<number>(10000);
  const [customFactorValue, setCustomFactorValue] = useState<number>(5.306);
  const [customUnit, setCustomUnit] = useState<string>('therms');
  const [evidenceDocName, setEvidenceDocName] = useState<string>('Utility_SmartMeter_Receipt.pdf');
  const [dataQualityTier, setDataQualityTier] = useState<DataQualityTier>('Tier 1 (Supplier Primary / Continuous Meter)');
  const [auditorNotes, setAuditorNotes] = useState<string>('Direct meter billing invoice reconciliation.');
  const [marketBasedDeductionTons, setMarketBasedDeductionTons] = useState<number>(0);

  // Available factors matching current scope
  const availableFactors = EMISSION_FACTOR_CATALOG.filter((f) => {
    if (scope === 'scope_1') {
      return ['stationary_combustion', 'mobile_combustion', 'fugitive_refrigerants'].includes(f.category);
    }
    if (scope === 'scope_2') {
      return ['purchased_electricity', 'district_heating'].includes(f.category);
    }
    if (scope === 'scope_3') {
      return f.category.startsWith('cat_');
    }
    return true;
  });

  // When scope changes, auto-select first matching factor
  useEffect(() => {
    if (availableFactors.length > 0) {
      const first = availableFactors[0];
      setSelectedFactorId(first.id);
      setCustomFactorValue(first.factorKgCO2e);
      setCustomUnit(first.unit);
      setActivityName(`${first.name} Consumption`);
    }
  }, [scope]);

  // When factor changes, update unit and value
  const handleFactorSelect = (factorId: string) => {
    setSelectedFactorId(factorId);
    const factor = EMISSION_FACTOR_CATALOG.find((f) => f.id === factorId);
    if (factor) {
      setCustomFactorValue(factor.factorKgCO2e);
      setCustomUnit(factor.unit);
      setActivityName(`${factor.name} Usage`);
    }
  };

  // Live calculation
  const liveEmissionsTons = calculateRecordEmissions(quantity, customFactorValue, marketBasedDeductionTons);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedFacility = facilities.find((f) => f.id === facilityId) || facilities[0];
    const selectedFactor = EMISSION_FACTOR_CATALOG.find((f) => f.id === selectedFactorId);

    const newRecord: ActivityRecord = {
      id: `rec_${Date.now()}`,
      date,
      facilityId: selectedFacility.id,
      facilityName: selectedFacility.name,
      scope,
      category: (selectedFactor?.category as any) || 'stationary_combustion',
      categoryLabel: selectedFactor?.name || 'Operational Activity',
      activityName: activityName.trim() || 'Operational Activity',
      quantity: Number(quantity),
      unit: customUnit,
      emissionFactorId: selectedFactorId,
      emissionFactorValue: Number(customFactorValue),
      emissionFactorUnit: `kgCO2e / ${customUnit}`,
      factorSource: selectedFactor?.source || 'DEFRA 2024 / EPA Hub',
      calculatedEmissionsTons: liveEmissionsTons,
      marketBasedDeductionTons: scope === 'scope_2' ? Number(marketBasedDeductionTons) : undefined,
      dataQualityTier,
      verificationStatus: 'ready_for_audit',
      evidenceDocName: evidenceDocName.trim() || undefined,
      auditorNotes: auditorNotes.trim() || undefined,
      costUsd: Math.round(Number(quantity) * 0.15)
    };

    onAddRecord(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-xl bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/60">
          <div>
            <h3 className="text-base font-bold text-white">Log Activity / Ingest Utility Data</h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Record verified operational activity data with automated emission factor calculation
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-white rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Scope Selector */}
          <div>
            <label className="block text-neutral-300 font-medium mb-1.5">Emission Scope</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'scope_1', label: 'Scope 1 (Direct)', desc: 'Natural gas, diesel, refrigerants' },
                { id: 'scope_2', label: 'Scope 2 (Energy)', desc: 'Electricity & district heat' },
                { id: 'scope_3', label: 'Scope 3 (Value Chain)', desc: 'Cloud, travel, transport, spend' }
              ].map((s) => (
                <button
                  type="button"
                  key={s.id}
                  onClick={() => setScope(s.id as EmissionScope)}
                  className={`p-2.5 rounded border text-left transition-colors ${
                    scope === s.id
                      ? 'bg-neutral-800 border-emerald-500 text-white'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <div className="font-semibold">{s.label}</div>
                  <div className="text-[10px] text-neutral-400 mt-0.5 line-clamp-1">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Facility & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-300 font-medium mb-1">Operational Facility</label>
              <select
                value={facilityId}
                onChange={(e) => setFacilityId(e.target.value)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs focus:outline-none focus:border-neutral-700"
              >
                {facilities.map((f) => (
                  <option key={f.id} value={f.id}>{f.name} ({f.city})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">Activity Date / Period</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs focus:outline-none focus:border-neutral-700 font-mono"
              />
            </div>
          </div>

          {/* Activity Description */}
          <div>
            <label className="block text-neutral-300 font-medium mb-1">Activity Description</label>
            <input
              type="text"
              value={activityName}
              onChange={(e) => setActivityName(e.target.value)}
              placeholder="e.g. Q3 Main Plant Chiller Electricity Consumption"
              className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs placeholder-neutral-500 focus:outline-none focus:border-neutral-700"
              required
            />
          </div>

          {/* Emission Factor Selector */}
          <div>
            <label className="block text-neutral-300 font-medium mb-1">
              Recognized Emission Factor Catalog
            </label>
            <select
              value={selectedFactorId}
              onChange={(e) => handleFactorSelect(e.target.value)}
              className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs focus:outline-none focus:border-neutral-700"
            >
              {availableFactors.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} — {f.factorKgCO2e} kgCO₂e/{f.unit} ({f.source})
                </option>
              ))}
            </select>
          </div>

          {/* Quantity & Unit & Factor Rate */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-neutral-300 font-medium mb-1">Activity Volume</label>
              <input
                type="number"
                step="any"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono focus:outline-none focus:border-neutral-700"
                required
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">Unit</label>
              <input
                type="text"
                value={customUnit}
                onChange={(e) => setCustomUnit(e.target.value)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono focus:outline-none focus:border-neutral-700"
              />
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">Factor (kgCO₂e/unit)</label>
              <input
                type="number"
                step="any"
                value={customFactorValue}
                onChange={(e) => setCustomFactorValue(Number(e.target.value))}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono focus:outline-none focus:border-neutral-700"
                required
              />
            </div>
          </div>

          {/* Scope 2 Market-Based Deduction (if applicable) */}
          {scope === 'scope_2' && (
            <div className="p-3 bg-neutral-900/80 border border-neutral-800 rounded-md">
              <label className="block text-neutral-300 font-medium mb-1">
                Bundled Contractual Renewable Offset / EAC Deduction (tCO₂e)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={marketBasedDeductionTons}
                  onChange={(e) => setMarketBasedDeductionTons(Number(e.target.value))}
                  placeholder="0"
                  className="w-40 p-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-200 text-xs font-mono focus:outline-none focus:border-neutral-700"
                />
                <span className="text-[11px] text-neutral-400">
                  Deducts retired Guarantees of Origin (GOs) or RECs for Market-Based calculation
                </span>
              </div>
            </div>
          )}

          {/* Quality Tier & Evidence Doc */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-300 font-medium mb-1">Data Quality Tier</label>
              <select
                value={dataQualityTier}
                onChange={(e) => setDataQualityTier(e.target.value as DataQualityTier)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs focus:outline-none focus:border-neutral-700"
              >
                <option value="Tier 1 (Supplier Primary / Continuous Meter)">Tier 1 (Continuous Meter / Invoice)</option>
                <option value="Tier 2 (Activity-specific / Regional Fuel Factor)">Tier 2 (Fuel-specific Factor)</option>
                <option value="Tier 3 (Spend-based Economic Model / Proxy)">Tier 3 (Spend Proxy / EEIO)</option>
              </select>
            </div>

            <div>
              <label className="block text-neutral-300 font-medium mb-1">Evidence Document Name</label>
              <input
                type="text"
                value={evidenceDocName}
                onChange={(e) => setEvidenceDocName(e.target.value)}
                placeholder="e.g. Utility_Bill_Invoice.pdf"
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs placeholder-neutral-500 focus:outline-none focus:border-neutral-700"
              />
            </div>
          </div>

          {/* Live Calculation Preview Banner */}
          <div className="p-3.5 bg-neutral-900 border border-emerald-800/60 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-neutral-400">Calculated Greenhouse Gas Output:</span>
                <div className="text-base font-bold font-mono text-emerald-400">
                  {formatNumber(liveEmissionsTons, 3)} <span className="text-xs font-normal text-white">metric tons CO₂e</span>
                </div>
              </div>
            </div>
            <div className="text-[11px] text-neutral-400 text-right">
              <div>Formula: {formatNumber(quantity)} × {customFactorValue} ÷ 1,000</div>
              <div className="text-emerald-400">Audit Ready</div>
            </div>
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Record & Calculate</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
