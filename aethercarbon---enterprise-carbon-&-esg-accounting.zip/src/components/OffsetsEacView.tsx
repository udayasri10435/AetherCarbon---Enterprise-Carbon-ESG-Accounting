import React, { useState } from 'react';
import { CarbonOffset, EACCertificate, EmissionsSummary } from '../types/carbon';
import { formatNumber, formatTons, formatCurrency } from '../utils/carbonEngine';
import { 
  ShieldCheck, 
  Leaf, 
  Zap, 
  ExternalLink, 
  CheckCircle, 
  Clock, 
  Plus, 
  Filter, 
  Info,
  Award,
  Sparkles,
  Lock
} from 'lucide-react';

interface OffsetsEacViewProps {
  offsets: CarbonOffset[];
  eacs: EACCertificate[];
  summary: EmissionsSummary;
  onRetireOffset: (offsetId: string) => void;
  onAddOffset: (offset: CarbonOffset) => void;
  onAddEAC: (eac: EACCertificate) => void;
}

export const OffsetsEacView: React.FC<OffsetsEacViewProps> = ({
  offsets,
  eacs,
  summary,
  onRetireOffset,
  onAddOffset,
  onAddEAC
}) => {
  const [activeTab, setActiveTab] = useState<'offsets' | 'eacs'>('offsets');
  const [filterType, setFilterType] = useState<string>('all');
  const [isRetiringId, setIsRetiringId] = useState<string | null>(null);

  // New Offset Modal State
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [projectName, setProjectName] = useState<string>('');
  const [registry, setRegistry] = useState<CarbonOffset['registry']>('Puro.earth (CDR)');
  const [removalType, setRemovalType] = useState<'durable_removal' | 'avoidance'>('durable_removal');
  const [quantityTons, setQuantityTons] = useState<number>(100);
  const [permanenceYears, setPermanenceYears] = useState<number>(1000);
  const [costPerTon, setCostPerTon] = useState<number>(190);

  const filteredOffsets = offsets.filter((o) => {
    if (filterType === 'all') return true;
    if (filterType === 'durable') return o.removalType === 'durable_removal';
    if (filterType === 'avoidance') return o.removalType === 'avoidance';
    if (filterType === 'retired') return o.status === 'retired_for_reporting';
    if (filterType === 'active') return o.status === 'active_in_portfolio';
    return true;
  });

  const totalDurableTons = offsets
    .filter(o => o.removalType === 'durable_removal')
    .reduce((a, b) => a + b.quantityTons, 0);

  const totalAvoidanceTons = offsets
    .filter(o => o.removalType === 'avoidance')
    .reduce((a, b) => a + b.quantityTons, 0);

  const totalEacMWh = eacs.reduce((a, b) => a + b.volumeMWh, 0);

  const handleCreateOffset = (e: React.FormEvent) => {
    e.preventDefault();
    const newOffset: CarbonOffset = {
      id: `off_${Date.now()}`,
      projectName: projectName.trim() || 'Verified Carbon Credit Batch',
      registry,
      serialNumber: `${registry.substring(0, 3).toUpperCase()}-CR-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
      vintageYear: new Date().getFullYear(),
      quantityTons: Number(quantityTons),
      projectType: removalType === 'durable_removal' ? 'Biochar / Mineral Carbon Storage' : 'Afforestation & Ecosystem Protection',
      removalType,
      permanenceRatingYears: Number(permanenceYears),
      additionalityScore: 'Very High',
      costPerTonUsd: Number(costPerTon),
      status: 'active_in_portfolio',
      certificateRef: `REG-CERT-${Math.floor(10000 + Math.random() * 90000)}`
    };

    onAddOffset(newOffset);
    setShowAddModal(false);
    setProjectName('');
  };

  return (
    <div className="space-y-6">
      {/* Header and Regulatory Guidance */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="font-semibold text-neutral-200">Oxford Offsetting Principles</span>
            <span aria-hidden="true">·</span>
            <span>GHG Protocol Scope 2 Guidance</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-mono">Registry Serial Audited</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Carbon Offsets & EAC Instruments Portfolio
          </h2>
          <p className="text-xs text-neutral-300 mt-1 max-w-3xl">
            Contractual energy attribute certificates (EACs/RECs/GOs) and high-permanence carbon removal (CDR) instruments with serial registry traceability.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Credit / EAC Batch</span>
          </button>
        </div>
      </div>

      {/* Regulatory Rule Explainer Callout (Anti-Slop, High-Information) */}
      <div className="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg flex items-start gap-3 text-xs">
        <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
        <div className="space-y-1 text-neutral-300">
          <strong className="text-white font-semibold">ESRS E1 & SBTi Compliance Accounting Rule:</strong>
          <p className="text-neutral-400 leading-relaxed">
            1. <strong className="text-neutral-200">EACs & Guarantees of Origin (GOs)</strong> are contractual instruments applied directly to reduce <em>Scope 2 Market-Based</em> emissions.
            <br />
            2. <strong className="text-neutral-200">Carbon Offsets (Avoidance)</strong> must be disclosed in <em>ESRS E1-7</em> and CANNOT be subtracted from Gross Scopes 1, 2, or 3.
            <br />
            3. <strong className="text-neutral-200">Durable Carbon Removals (CDR &gt;1,000 years)</strong> neutralize residual unabated emissions under the SBTi Net-Zero Standard.
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Total Retired EAC Energy</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {formatNumber(totalEacMWh, 0)} <span className="text-xs font-normal text-neutral-400 font-sans">MWh</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            -718.6 tCO₂e Scope 2 market reduction
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Durable Carbon Removal (CDR)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {formatNumber(totalDurableTons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Puro.earth Biochar & Direct Air Capture
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Avoidance Credits In Portfolio</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {formatNumber(totalAvoidanceTons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Verra VCS & Gold Standard verified
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Net Residual Position</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {formatNumber(summary.netMarketTons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            Residual neutralization active
          </div>
        </div>
      </div>

      {/* Segmented Tab Controls: Offsets vs EACs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-md text-xs">
          <button
            onClick={() => setActiveTab('offsets')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'offsets'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Carbon Offsets & Removals ({offsets.length})
          </button>
          <button
            onClick={() => setActiveTab('eacs')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'eacs'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Renewable EACs & GOs ({eacs.length})
          </button>
        </div>

        {activeTab === 'offsets' && (
          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-400">Filter:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-2.5 py-1.5 bg-neutral-900 border border-neutral-800 rounded text-neutral-300 text-xs focus:outline-none"
            >
              <option value="all">All Credits</option>
              <option value="durable">Durable Removals Only (&gt;1,000yr)</option>
              <option value="avoidance">Avoidance Projects</option>
              <option value="retired">Retired for Reporting</option>
              <option value="active">Active in Portfolio</option>
            </select>
          </div>
        )}
      </div>

      {/* Main Table for Carbon Offsets */}
      {activeTab === 'offsets' && (
        <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-900">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 bg-neutral-950 text-neutral-400 font-medium">
                  <th className="py-2.5 px-4">Project & Registry</th>
                  <th className="py-2.5 px-3">Removal Category</th>
                  <th className="py-2.5 px-3">Serial Range & Certificate</th>
                  <th className="py-2.5 px-3 text-center">Vintage</th>
                  <th className="py-2.5 px-3 text-center">Permanence</th>
                  <th className="py-2.5 px-3 text-right">Volume</th>
                  <th className="py-2.5 px-3 text-right">Unit Price</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredOffsets.map((o) => {
                  const isDurable = o.removalType === 'durable_removal';
                  const isRetired = o.status === 'retired_for_reporting';

                  return (
                    <tr key={o.id} className="hover:bg-neutral-800/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white truncate max-w-[240px]">
                          {o.projectName}
                        </div>
                        <div className="text-[11px] text-neutral-400 mt-0.5">
                          {o.registry} · {o.projectType}
                        </div>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        {isDurable ? (
                          <span className="text-emerald-400 font-medium inline-flex items-center gap-1 text-[11px]">
                            <Sparkles className="w-3 h-3" /> Durable Removal
                          </span>
                        ) : (
                          <span className="text-neutral-400 font-medium inline-flex items-center gap-1 text-[11px]">
                            <Leaf className="w-3 h-3 text-neutral-500" /> Avoidance
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 font-mono text-[11px] text-neutral-300">
                        <div className="truncate max-w-[200px] text-neutral-200">{o.serialNumber}</div>
                        <div className="text-neutral-500 text-[10px] mt-0.5">{o.certificateRef}</div>
                      </td>

                      <td className="py-3 px-3 text-center font-mono tabular-nums text-neutral-300 whitespace-nowrap">
                        {o.vintageYear}
                      </td>

                      <td className="py-3 px-3 text-center font-mono tabular-nums text-neutral-300 whitespace-nowrap">
                        {o.permanenceRatingYears >= 1000 ? `${o.permanenceRatingYears} yrs` : `${o.permanenceRatingYears} yrs`}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-white whitespace-nowrap">
                        {formatNumber(o.quantityTons, 1)} <span className="font-normal text-neutral-400 font-sans text-[11px]">tCO₂e</span>
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-300 whitespace-nowrap">
                        {formatCurrency(o.costPerTonUsd)}/t
                      </td>

                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        {isRetired ? (
                          <span className="text-[11px] text-emerald-400 font-medium inline-flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Retired ({o.retirementDate?.split('-')[0]})
                          </span>
                        ) : (
                          <span className="text-[11px] text-sky-400 font-medium inline-flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Active Portfolio
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {!isRetired ? (
                          <button
                            onClick={() => onRetireOffset(o.id)}
                            className="px-2.5 py-1 text-xs font-medium text-emerald-300 bg-emerald-950/80 border border-emerald-800 rounded hover:bg-emerald-900 transition-colors"
                          >
                            Retire Credit
                          </button>
                        ) : (
                          <span className="text-[11px] text-neutral-500 font-mono">
                            Locked for Audit
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Main Table for EACs (Guarantees of Origin / RECs) */}
      {activeTab === 'eacs' && (
        <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-900">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-neutral-800 bg-neutral-950 text-neutral-400 font-medium">
                  <th className="py-2.5 px-4">Certificate Type & Source</th>
                  <th className="py-2.5 px-3">Allocated Facility</th>
                  <th className="py-2.5 px-3">Serial Identifier</th>
                  <th className="py-2.5 px-3 text-center">Vintage</th>
                  <th className="py-2.5 px-3 text-right">Volume (MWh)</th>
                  <th className="py-2.5 px-3 text-right">Scope 2 Abated</th>
                  <th className="py-2.5 px-3 text-center">Reporting Period</th>
                  <th className="py-2.5 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60 font-mono">
                {eacs.map((e) => (
                  <tr key={e.id} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="py-3 px-4 font-sans">
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{e.certificateType}</span>
                      </div>
                      <div className="text-[11px] text-neutral-400 mt-0.5">
                        {e.generationSource} Power Generation
                      </div>
                    </td>

                    <td className="py-3 px-3 font-sans text-neutral-300">
                      {e.facilityName}
                    </td>

                    <td className="py-3 px-3 text-[11px] text-neutral-300 truncate max-w-[200px]">
                      {e.serialNumber}
                    </td>

                    <td className="py-3 px-3 text-center text-neutral-300">
                      {e.vintageYear}
                    </td>

                    <td className="py-3 px-3 text-right font-bold text-white">
                      {formatNumber(e.volumeMWh, 1)} MWh
                    </td>

                    <td className="py-3 px-3 text-right text-emerald-400 font-bold">
                      -{formatNumber(e.emissionsAvoidedTons, 2)} tCO₂e
                    </td>

                    <td className="py-3 px-3 text-center text-neutral-300 font-sans">
                      {e.retiredForPeriod}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="text-[11px] text-emerald-400 font-medium inline-flex items-center gap-1 font-sans">
                        <CheckCircle className="w-3 h-3" /> Retired in EECS
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: Add New Credit / EAC */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-neutral-950 border border-neutral-800 rounded-lg p-6 space-y-4 animate-in zoom-in-95 duration-150 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-base font-bold text-white">Register Verified Offset or EAC Batch</h3>
              <button onClick={() => setShowAddModal(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateOffset} className="space-y-3.5">
              <div>
                <label className="block text-neutral-300 font-medium mb-1">Project Name</label>
                <input
                  type="text"
                  placeholder="e.g. Nordic Mineralization & Biochar CDR Project"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-300 font-medium mb-1">Standard Registry</label>
                  <select
                    value={registry}
                    onChange={(e) => setRegistry(e.target.value as any)}
                    className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs"
                  >
                    <option value="Puro.earth (CDR)">Puro.earth (Durable CDR)</option>
                    <option value="Verra (VCS)">Verra (VCS Standard)</option>
                    <option value="Gold Standard">Gold Standard</option>
                    <option value="American Carbon Registry (ACR)">American Carbon Registry</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-300 font-medium mb-1">Removal Category</label>
                  <select
                    value={removalType}
                    onChange={(e) => {
                      const val = e.target.value as 'durable_removal' | 'avoidance';
                      setRemovalType(val);
                      setPermanenceYears(val === 'durable_removal' ? 1000 : 40);
                    }}
                    className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs"
                  >
                    <option value="durable_removal">Durable Removal (&gt;1,000 yrs)</option>
                    <option value="avoidance">Avoidance / Reduction</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-neutral-300 font-medium mb-1">Volume (tCO₂e)</label>
                  <input
                    type="number"
                    min="1"
                    value={quantityTons}
                    onChange={(e) => setQuantityTons(Number(e.target.value))}
                    className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-medium mb-1">Permanence (Years)</label>
                  <input
                    type="number"
                    value={permanenceYears}
                    onChange={(e) => setPermanenceYears(Number(e.target.value))}
                    className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-neutral-300 font-medium mb-1">Cost ($/tCO₂e)</label>
                  <input
                    type="number"
                    value={costPerTon}
                    onChange={(e) => setCostPerTon(Number(e.target.value))}
                    className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded text-neutral-200 text-xs font-mono"
                    required
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-neutral-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded"
                >
                  Register to Portfolio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
