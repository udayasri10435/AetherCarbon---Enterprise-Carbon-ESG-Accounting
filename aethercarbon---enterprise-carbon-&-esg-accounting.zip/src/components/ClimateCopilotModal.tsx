import React, { useState } from 'react';
import { EmissionsSummary, ActivityRecord } from '../types/carbon';
import { answerClimateQuery, CopilotMessage } from '../utils/aiCopilot';
import { 
  Sparkles, 
  X, 
  Send, 
  ShieldAlert, 
  ArrowRight, 
  CheckCircle2, 
  Bot, 
  User,
  HelpCircle
} from 'lucide-react';

interface ClimateCopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: EmissionsSummary;
  records: ActivityRecord[];
  onNavigateToTab: (tab: string) => void;
  onOpenAuditExport: () => void;
}

export const ClimateCopilotModal: React.FC<ClimateCopilotModalProps> = ({
  isOpen,
  onClose,
  summary,
  records,
  onNavigateToTab,
  onOpenAuditExport
}) => {
  if (!isOpen) return null;

  const [input, setInput] = useState<string>('');
  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      timestamp: 'Just now',
      text: `Hello! I am your AI Climate & Regulatory Accounting Copilot. I analyze your Scope 1, 2, and 3 ledger, CSRD / ESRS E1 disclosures, and SBTi 1.5°C targets in real time. 

Current Snapshot:
• Gross Market Emissions: ${summary.totalGrossMarketTons.toLocaleString()} tCO₂e (-${(((4820 - summary.totalGrossMarketTons) / 4820) * 100).toFixed(1)}% vs 2022)
• Renewable Power Mix: ${summary.renewableEnergyPercent}%
• Durable CDR Retired: ${summary.retiredDurableRemovalsTons} tCO₂e

How can I assist your audit preparation or decarbonization modeling today?`
    }
  ]);

  const quickPrompts = [
    'What are the penalty risks for California SB 253?',
    'How do we close our remaining 2030 SBTi gap?',
    'Why does ESRS E1 forbid offset netting in Scope 1?',
    'Which Scope 3 categories have high uncertainty?'
  ];

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: CopilotMessage = {
      id: `msg_u_${Date.now()}`,
      sender: 'user',
      timestamp: 'Just now',
      text: query
    };

    const replyText = answerClimateQuery(query, summary);

    const botMsg: CopilotMessage = {
      id: `msg_a_${Date.now()}`,
      sender: 'assistant',
      timestamp: 'Just now',
      text: replyText
    };

    setMessages(prev => [...prev, userMsg, botMsg]);
    setInput('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden shadow-2xl flex flex-col h-[650px] animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-950 border border-emerald-800 rounded text-emerald-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>AI Carbon & Regulatory Copilot</span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-1.5 py-0.2 rounded">
                  ISAE 3000 Mode
                </span>
              </h3>
              <p className="text-[11px] text-neutral-400">
                Trained on GHG Protocol, ESRS E1, SBTi Corporate Standard, and SEC Item 1500
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-white rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
          {messages.map((m) => {
            const isBot = m.sender === 'assistant';
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isBot ? 'items-start' : 'items-start flex-row-reverse'}`}
              >
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-xs ${
                    isBot ? 'bg-emerald-950 border border-emerald-800 text-emerald-400' : 'bg-neutral-800 text-white'
                  }`}
                >
                  {isBot ? <Bot className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
                </div>

                <div
                  className={`max-w-[85%] p-3.5 rounded-lg text-xs leading-relaxed whitespace-pre-line ${
                    isBot
                      ? 'bg-neutral-900 border border-neutral-800 text-neutral-200'
                      : 'bg-emerald-600 text-neutral-950 font-medium'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Question Prompts */}
        <div className="px-4 py-2 bg-neutral-900/60 border-t border-neutral-800/80 overflow-x-auto flex items-center gap-2 text-[11px]">
          <span className="text-neutral-500 whitespace-nowrap">Suggested:</span>
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="px-2.5 py-1 bg-neutral-900 border border-neutral-800 rounded text-neutral-300 hover:text-white hover:border-neutral-700 whitespace-nowrap transition-colors"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-neutral-900 border-t border-neutral-800 flex items-center gap-2 shrink-0">
          <input
            type="text"
            placeholder="Ask about CSRD compliance, Scope 3 factors, SBTi gap closure..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            className="flex-1 p-2.5 bg-neutral-950 border border-neutral-800 rounded-md text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-neutral-700"
          />
          <button
            onClick={() => handleSend()}
            className="p-2.5 bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded-md font-semibold transition-colors shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
