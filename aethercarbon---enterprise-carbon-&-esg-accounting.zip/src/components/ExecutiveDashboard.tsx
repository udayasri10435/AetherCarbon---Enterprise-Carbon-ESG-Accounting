import React, { useState } from 'react';
import { 
  EmissionsSummary, 
  Facility, 
  ActivityRecord, 
  CarbonOffset,
  EACCertificate 
} from '../types/carbon';
import { 
  formatTons, 
  formatNumber, 
  formatCurrency 
} from '../utils/carbonEngine';
import { 
  AlertTriangle, 
  ArrowUpRight, 
  CheckCircle2, 
  Building2, 
  Leaf, 
  TrendingDown, 
  FileText,
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';

interface ExecutiveDashboardProps {
  summary: EmissionsSummary;
  facilities: Facility[];
  records: ActivityRecord[];
  offsets: CarbonOffset[];
  eacs: EACCertificate[];
  onNavigateToTab: (tab: string) => void;
  onOpenLogModal: () => void;
  anomalies: string[];
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  summary,
  facilities,
  records,
  offsets,
  eacs,
  onNavigateToTab,
  onOpenLogModal,
  anomalies
}) => {
  const [scopeMethod, setScopeMethod] = useState<'market_based' | 'location_based'>('market_based');
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>('all');

  // Baseline 2022 comparison
  const baselineTons2022 = 4820.0;
  const currentTotal = scopeMethod === 'market_based' ? summary.totalGrossMarketTons : summary.totalGrossLocationTons;
  const reductionPercentVsBaseline = (((baselineTons2022 - currentTotal) / baselineTons2022) * 100).toFixed(1);

  // Filter records if facility selected
  const activeRecords = selectedFacilityId === 'all' 
    ? records 
    : records.filter(r => r.facilityId === selectedFacilityId);

  // Group Scope 3 records by category for visual breakdown
  const scope3ByCategory: Record<string, { label: string; tons: number }> = {};
  for (const r of activeRecords) {
    if (r.scope === 'scope_3') {
      if (!scope3ByCategory[r.category]) {
        scope3ByCategory[r.category] = { label: r.categoryLabel, tons: 0 };
      }
      scope3ByCategory[r.category].tons += r.calculatedEmissionsTons;
    }
  }

  // Verification counts
  const verifiedCount = records.filter(r => r.verificationStatus === 'auditor_verified').length;
  const readyCount = records.filter(r => r.verificationStatus === 'ready_for_audit').length;
  const reviewCount = records.filter(r => r.verificationStatus === 'draft_review').length;

  return (
    <div className="space-y-6">
      {/* Top Banner: Regulatory Urgency & Baseline Achievement */}
      <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 shrink-0 mt-0.5 sm:mt-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="font-semibold text-neutral-200 uppercase tracking-wider text-[11px]">CSRD & SB 253 Mandate Readiness</span>
              <span aria-hidden="true">·</span>
              <span>ISAE 3000 Pre-Assurance</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400">92% Audit Complete</span>
            </div>
            <p className="text-sm text-neutral-300 mt-0.5">
              Consolidated emissions stand at <strong className="text-white font-mono">{formatTons(currentTotal)}</strong> ({reductionPercentVsBaseline}% below 2022 baseline). On track for verified 2026 CSRD limited assurance filing.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {/* Scope 2 Method Toggle */}
          <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-md text-xs">
            <button
              onClick={() => setScopeMethod('market_based')}
              className={`px-2.5 py-1 rounded transition-colors ${
                scopeMethod === 'market_based'
                  ? 'bg-neutral-800 text-white font-medium'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Dual accounting: Deducts certified contractual instruments (PPAs, GOs, RECs)"
            >
              Market-Based
            </button>
            <button
              onClick={() => setScopeMethod('location_based')}
              className={`px-2.5 py-1 rounded transition-colors ${
                scopeMethod === 'location_based'
                  ? 'bg-neutral-800 text-white font-medium'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Dual accounting: Uses regional grid average emission factors"
            >
              Location-Based
            </button>
          </div>

          <button
            onClick={() => onNavigateToTab('csrd')}
            className="flex items-center gap-1 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors whitespace-nowrap"
          >
            <span>ESRS E1 Tables</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Anomaly Alerts if any */}
      {anomalies.length > 0 && (
        <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg flex items-start gap-2.5 text-xs text-amber-200">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <span className="font-semibold text-amber-300">Auditor Pre-Flight Notice ({anomalies.length} items):</span>
            <ul className="list-disc list-inside space-y-0.5 text-amber-200/90">
              {anomalies.map((anom, idx) => (
                <li key={idx}>{anom}</li>
              ))}
            </ul>
          </div>
          <button 
            onClick={() => onNavigateToTab('ledger')}
            className="text-amber-300 hover:text-amber-100 underline whitespace-nowrap ml-2"
          >
            Review Ledger
          </button>
        </div>
      )}

      {/* Primary KPI Grid (60-30-10, flat single-elevation, high-density) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total Gross Emissions */}
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Gross GHG Emissions</span>
            <span className="text-[11px] font-mono capitalize">{scopeMethod.replace('_', ' ')}</span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tracking-tight text-white">
            {formatNumber(currentTotal, 1)} <span className="text-sm font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-800/60">
            <span className="flex items-center gap-1 text-emerald-400 font-mono">
              <TrendingDown className="w-3.5 h-3.5" />
              <span>-{reductionPercentVsBaseline}% vs 2022</span>
            </span>
            <span>Target: 2,390 t</span>
          </div>
        </div>

        {/* Metric 2: Scope 1 Direct */}
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Scope 1 (Direct Fuels & Fugitive)</span>
            <span className="text-[11px] font-mono">
              {((summary.scope1Tons / currentTotal) * 100).toFixed(1)}% of total
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tracking-tight text-white">
            {formatNumber(summary.scope1Tons, 1)} <span className="text-sm font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-800/60">
            <span>Gas + Diesel + Fleet + R-410A</span>
            <span className="text-neutral-300 font-mono">4 Activity Streams</span>
          </div>
        </div>

        {/* Metric 3: Scope 2 Electricity (Dual Reporting) */}
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Scope 2 (Purchased Energy)</span>
            <span className="text-emerald-400 text-[11px] font-mono">
              -{(summary.scope2LocationBasedTons - summary.scope2MarketBasedTons).toFixed(0)}t via EACs
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tracking-tight text-white">
            {formatNumber(scopeMethod === 'market_based' ? summary.scope2MarketBasedTons : summary.scope2LocationBasedTons, 1)}{' '}
            <span className="text-sm font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-800/60">
            <span>Location: {summary.scope2LocationBasedTons.toFixed(0)}t</span>
            <span className="text-emerald-400 font-mono">{summary.renewableEnergyPercent}% Renewable</span>
          </div>
        </div>

        {/* Metric 4: Scope 3 Value Chain */}
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Scope 3 (Upstream & Downstream)</span>
            <span className="text-[11px] font-mono">
              {((summary.scope3Tons / currentTotal) * 100).toFixed(1)}% of total
            </span>
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tracking-tight text-white">
            {formatNumber(summary.scope3Tons, 1)} <span className="text-sm font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-neutral-800/60">
            <span>6 Material Categories</span>
            <span className="text-neutral-300 font-mono">Cat 1 & 4 Dominant</span>
          </div>
        </div>
      </div>

      {/* Secondary Metrics: Energy & Offsets & Carbon Intensity */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Total Group Energy & Mix</div>
            <div className="text-xl font-bold font-mono text-white mt-1">
              {formatNumber(summary.energyTotalMWh, 0)} <span className="text-xs font-normal text-neutral-400 font-sans">MWh</span>
            </div>
            <div className="text-xs text-emerald-400 mt-1">
              {formatNumber(summary.renewableEnergyMWh, 0)} MWh from certified PPA & GOs
            </div>
          </div>
          <div className="w-12 h-12 rounded-full border-4 border-neutral-800 border-t-emerald-400 flex items-center justify-center font-mono text-xs font-bold text-white">
            {summary.renewableEnergyPercent}%
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Durable Carbon Removals (CDR)</div>
            <div className="text-xl font-bold font-mono text-white mt-1">
              {formatNumber(summary.retiredDurableRemovalsTons, 0)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
            </div>
            <div className="text-xs text-neutral-400 mt-1">
              Puro.earth Biochar & DAC (&gt;1,000yr permanence)
            </div>
          </div>
          <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-300">
            <Leaf className="w-5 h-5 text-emerald-400" />
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Carbon Revenue Intensity (ESRS E1-6)</div>
            <div className="text-xl font-bold font-mono text-white mt-1">
              {summary.intensityPerMRevenue} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e / $M</span>
            </div>
            <div className="text-xs text-emerald-400 mt-1">
              -14.8% YoY decoupling efficiency
            </div>
          </div>
          <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-300">
            <Zap className="w-5 h-5 text-amber-400" />
          </div>
        </div>
      </div>

      {/* Main Visualizations: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: SBTi 1.5°C Paris Trajectory Chart (7 cols) */}
        <div className="lg:col-span-7 p-5 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">SBTi 1.5°C Decarbonization Trajectory</h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                Validated 4.2% annual linear reduction target vs actual group performance (2022–2040)
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.5 rounded">
              Ahead of Glidepath
            </span>
          </div>

          {/* SVG Trajectory Visualization */}
          <div className="relative pt-2 pb-1">
            <svg viewBox="0 0 600 240" className="w-full h-auto overflow-visible">
              <defs>
                <linearGradient id="targetGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="actualLineGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#34d399" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="50" y1="20" x2="570" y2="20" stroke="#262626" strokeDasharray="3,3" />
              <line x1="50" y1="70" x2="570" y2="70" stroke="#262626" strokeDasharray="3,3" />
              <line x1="50" y1="120" x2="570" y2="120" stroke="#262626" strokeDasharray="3,3" />
              <line x1="50" y1="170" x2="570" y2="170" stroke="#262626" strokeDasharray="3,3" />
              <line x1="50" y1="210" x2="570" y2="210" stroke="#404040" />

              {/* Y-axis Labels */}
              <text x="40" y="24" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">5,000t</text>
              <text x="40" y="74" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">3,750t</text>
              <text x="40" y="124" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">2,500t</text>
              <text x="40" y="174" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">1,250t</text>
              <text x="40" y="214" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">0t</text>

              {/* SBTi Target Trajectory (Dashed) */}
              {/* 2022 (50, 27) -> 2026 (170, 83) -> 2030 (290, 115) -> 2040 (550, 195) */}
              <path
                d="M 50 27 L 170 83 L 290 115 L 550 195"
                fill="none"
                stroke="#6b7280"
                strokeWidth="2"
                strokeDasharray="4,4"
              />

              {/* Area under actual path */}
              <path
                d="M 50 27 L 110 58 L 170 91 L 170 210 L 50 210 Z"
                fill="url(#targetGradient)"
              />

              {/* Actual Tracked Emissions (Solid Green) */}
              {/* 2022: 4,820t (y=27) -> 2024: 3,920t (y=61) -> 2026: 1,911t (y=137) */}
              <path
                d="M 50 27 L 110 61 L 170 137"
                fill="none"
                stroke="url(#actualLineGradient)"
                strokeWidth="3.5"
              />

              {/* Projected path with planned levers */}
              <path
                d="M 170 137 L 290 148 L 550 200"
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
                strokeDasharray="2,2"
                opacity="0.8"
              />

              {/* Key Milestones & Data Points */}
              {/* 2022 Baseline */}
              <circle cx="50" cy="27" r="4.5" fill="#10b981" stroke="#0a0a0a" strokeWidth="2" />
              <text x="50" y="225" textAnchor="middle" className="text-[10px] fill-neutral-300 font-mono">2022 (Base)</text>

              {/* 2024 Past */}
              <circle cx="110" cy="61" r="3.5" fill="#10b981" stroke="#0a0a0a" strokeWidth="1.5" />
              <text x="110" y="225" textAnchor="middle" className="text-[10px] fill-neutral-400 font-mono">2024</text>

              {/* 2026 Current */}
              <circle cx="170" cy="137" r="5" fill="#34d399" stroke="#0a0a0a" strokeWidth="2" />
              <text x="170" y="225" textAnchor="middle" className="text-[10px] fill-emerald-400 font-semibold font-mono">2026 (Now)</text>
              <rect x="135" y="105" width="70" height="20" rx="3" fill="#171717" stroke="#34d399" strokeWidth="1" />
              <text x="170" y="119" textAnchor="middle" className="text-[10px] fill-white font-mono font-bold">1,912 t</text>

              {/* 2030 Interim Target */}
              <circle cx="290" cy="115" r="4" fill="#6b7280" stroke="#0a0a0a" strokeWidth="1.5" />
              <text x="290" y="225" textAnchor="middle" className="text-[10px] fill-neutral-400 font-mono">2030 (Target)</text>
              <text x="290" y="105" textAnchor="middle" className="text-[10px] fill-neutral-400 font-mono">2,390 t max</text>

              {/* 2040 Net-Zero */}
              <circle cx="550" cy="195" r="4" fill="#6b7280" stroke="#0a0a0a" strokeWidth="1.5" />
              <text x="550" y="225" textAnchor="middle" className="text-[10px] fill-neutral-400 font-mono">2040 Net-Zero</text>
              <text x="550" y="185" textAnchor="middle" className="text-[10px] fill-neutral-400 font-mono">&lt;482 t residual</text>
            </svg>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-emerald-400 inline-block"></span>
                <span>Actual Audited Trajectory</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 border-b border-dashed border-neutral-500 inline-block"></span>
                <span>SBTi 1.5°C Ceiling (-4.2%/yr)</span>
              </span>
            </div>
            <button
              onClick={() => onNavigateToTab('pathways')}
              className="text-emerald-400 hover:text-emerald-300 font-medium"
            >
              Simulate Levers &rarr;
            </button>
          </div>
        </div>

        {/* Right Column: Facility Carbon Intensity Comparison (5 cols) */}
        <div className="lg:col-span-5 p-5 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-white">Facility Carbon Performance</h3>
                <p className="text-xs text-neutral-400 mt-0.5">Location vs Market emissions per site</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-neutral-400">
                <Building2 className="w-3.5 h-3.5" />
                <span>4 Sites</span>
              </div>
            </div>

            <div className="space-y-3.5 mt-2">
              {facilities.map((fac) => {
                // calculate facility emissions
                const facRecords = records.filter(r => r.facilityId === fac.id);
                const facS1 = facRecords.filter(r => r.scope === 'scope_1').reduce((a, b) => a + b.calculatedEmissionsTons, 0);
                const facS2Location = facRecords.filter(r => r.scope === 'scope_2').reduce((a, b) => a + b.calculatedEmissionsTons, 0);
                const facS2Deductions = facRecords.filter(r => r.scope === 'scope_2').reduce((a, b) => a + (b.marketBasedDeductionTons || 0), 0);
                const facS2Market = Math.max(0, facS2Location - facS2Deductions);
                const facTotalMarket = facS1 + facS2Market;

                return (
                  <div key={fac.id} className="p-3 bg-neutral-950/70 border border-neutral-800/80 rounded-md">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-white truncate max-w-[200px]">{fac.name}</span>
                      <span className="font-mono text-emerald-400 font-semibold">{formatTons(facTotalMarket)}</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-1">
                      <span>{fac.city}, {fac.country}</span>
                      <span>{fac.renewablePpaPercent}% PPA Clean Power</span>
                    </div>

                    {/* Progress Bar of Clean Power */}
                    <div className="w-full bg-neutral-800 h-1.5 rounded-full mt-2 overflow-hidden">
                      <div 
                        className="bg-emerald-400 h-full rounded-full transition-all"
                        style={{ width: `${fac.renewablePpaPercent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 mt-4 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
            <span>Audit Trail: 100% Primary Metering</span>
            <button
              onClick={() => onNavigateToTab('ledger')}
              className="text-emerald-400 hover:text-emerald-300 font-medium"
            >
              Inspect Site Meters &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Scope 3 Material Categories & Data Quality Breakdown */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Scope 3 Value-Chain Inventory (GHG Protocol 15 Categories)</h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Materiality threshold applied: 6 categories active; Tier 1 supplier PCFs replacing spend proxies
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-400">Total Scope 3:</span>
            <span className="font-mono font-bold text-white">{formatTons(summary.scope3Tons)}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Object.entries(scope3ByCategory).map(([catKey, data]) => {
            const shareOfScope3 = ((data.tons / summary.scope3Tons) * 100).toFixed(1);
            return (
              <div key={catKey} className="p-3 bg-neutral-950/60 border border-neutral-800/80 rounded-md flex flex-col justify-between">
                <div>
                  <div className="text-xs font-medium text-neutral-200 truncate">{data.label}</div>
                  <div className="text-lg font-bold font-mono text-white mt-1">
                    {formatNumber(data.tons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
                  </div>
                </div>

                <div className="mt-2 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[11px] text-neutral-400">
                  <span>{shareOfScope3}% of Scope 3</span>
                  <span className="text-emerald-400">Verified</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Audit Readiness Summary Bar */}
      <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded bg-neutral-950 border border-neutral-800 text-neutral-300">
            <FileText className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <span className="font-semibold text-white">Evidence Archive & Audit Readiness Status</span>
            <div className="text-neutral-400 mt-0.5">
              {verifiedCount} records Auditor Verified · {readyCount} Ready for Sign-off · {reviewCount} in Internal Review
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateToTab('ledger')}
            className="px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-950 border border-neutral-800 rounded hover:bg-neutral-800 transition-colors"
          >
            Review Evidence Documents
          </button>
          <button
            onClick={() => onNavigateToTab('csrd')}
            className="px-3 py-1.5 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
          >
            Review CSRD Disclosure Pack
          </button>
        </div>
      </div>
    </div>
  );
};
