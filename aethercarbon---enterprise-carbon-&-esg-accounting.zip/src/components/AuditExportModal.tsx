import React, { useState } from 'react';
import { EmissionsSummary, ActivityRecord, Facility, CarbonOffset, EACCertificate, CSRDDisclosureSection } from '../types/carbon';
import { formatNumber, formatTons, formatCurrency } from '../utils/carbonEngine';
import { 
  X, 
  Printer, 
  Download, 
  Copy, 
  Check, 
  ShieldCheck, 
  FileText, 
  Code,
  Building,
  CheckCircle2
} from 'lucide-react';

interface AuditExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: EmissionsSummary;
  records: ActivityRecord[];
  facilities: Facility[];
  offsets: CarbonOffset[];
  eacs: EACCertificate[];
  disclosures: CSRDDisclosureSection[];
}

export const AuditExportModal: React.FC<AuditExportModalProps> = ({
  isOpen,
  onClose,
  summary,
  records,
  facilities,
  offsets,
  eacs,
  disclosures
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'preview' | 'xbrl_json'>('preview');
  const [copied, setCopied] = useState<boolean>(false);

  const auditTimestamp = new Date().toISOString();
  const auditHash = '8f2a991b07ec34710db84218aef729904d1c4e976691c94b72ef31049281aef1';

  const xbrlData = {
    "@context": "https://xbrl.efrag.org/taxonomy/esrs/2024",
    "reportEntity": {
      "identifier": "LEI-5493006M91724018274",
      "legalName": "Apex Global Technologies & Logistics Inc.",
      "country": "US/EU Consolidated"
    },
    "reportingPeriod": "2026-01-01/2026-12-31",
    "assuranceStandard": "ISAE 3000 (Revised) Limited Assurance",
    "ESRS_E1_Metrics": {
      "GrossScope1_tCO2e": summary.scope1Tons,
      "GrossScope2_Location_tCO2e": summary.scope2LocationBasedTons,
      "GrossScope2_Market_tCO2e": summary.scope2MarketBasedTons,
      "GrossScope3_tCO2e": summary.scope3Tons,
      "TotalGrossGHG_Market_tCO2e": summary.totalGrossMarketTons,
      "TotalEnergyConsumption_MWh": summary.energyTotalMWh,
      "RenewableEnergyShare_Percent": summary.renewableEnergyPercent,
      "GHGIntensity_Revenue_tCO2e_MUSD": summary.intensityPerMRevenue,
      "DurableCarbonRemovalsRetired_tCO2e": summary.retiredDurableRemovalsTons,
      "AvoidanceOffsetsRetired_tCO2e": summary.retiredAvoidanceOffsetsTons,
      "NetMarketReportedEmissions_tCO2e": summary.netMarketTons
    },
    "verificationHash": auditHash,
    "timestamp": auditTimestamp
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(xbrlData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadXbrl = () => {
    const blob = new Blob([JSON.stringify(xbrlData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ESRS_E1_XBRL_AuditPack_ApexGlobal_FY2026.json`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-950 border border-emerald-800 rounded text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Official Auditor Verification Pack</h3>
              <p className="text-xs text-neutral-400">
                Statutory CSRD ESRS E1 & GHG Protocol Consolidated Assurance File
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-0.5 bg-neutral-950 border border-neutral-800 rounded text-xs">
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1 rounded transition-colors ${
                  activeTab === 'preview' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
                }`}
              >
                Executive Print View
              </button>
              <button
                onClick={() => setActiveTab('xbrl_json')}
                className={`px-3 py-1 rounded transition-colors ${
                  activeTab === 'xbrl_json' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
                }`}
              >
                XBRL / Digital ESEF Tagging
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1 text-neutral-400 hover:text-white rounded ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body Viewport */}
        <div className="flex-1 overflow-y-auto p-6 text-xs">
          {activeTab === 'preview' ? (
            <div className="space-y-6 max-w-3xl mx-auto bg-neutral-900 border border-neutral-800 p-8 rounded-lg shadow-sm print:bg-white print:text-black print:p-0 print:border-0">
              {/* Document Header */}
              <div className="flex items-start justify-between border-b border-neutral-800 pb-6 print:border-neutral-300">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 print:text-emerald-700">
                    Statutory Limited Assurance File
                  </span>
                  <h1 className="text-xl font-bold text-white mt-1 print:text-black">
                    Apex Global Technologies & Logistics Inc.
                  </h1>
                  <p className="text-xs text-neutral-400 mt-1 print:text-neutral-600">
                    Consolidated GHG Inventory & CSRD ESRS E1 Climate Change Disclosures
                  </p>
                </div>
                <div className="text-right font-mono text-[11px] text-neutral-400 print:text-neutral-600 space-y-0.5">
                  <div>Period: <strong className="text-white print:text-black">FY2026</strong></div>
                  <div>Standard: <strong className="text-white print:text-black">ISAE 3000 / 3410</strong></div>
                  <div>Status: <span className="text-emerald-400 font-bold print:text-emerald-700">Ready for Attestation</span></div>
                </div>
              </div>

              {/* Legal Entity & Boundary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 border-b border-neutral-800 print:border-neutral-300 text-xs">
                <div>
                  <span className="text-neutral-500">Consolidation Approach:</span>
                  <div className="font-semibold text-neutral-200 print:text-black mt-0.5">Operational Control</div>
                </div>
                <div>
                  <span className="text-neutral-500">Operational Sites:</span>
                  <div className="font-semibold text-neutral-200 print:text-black mt-0.5">4 Facilities (US, DE, NL, JP)</div>
                </div>
                <div>
                  <span className="text-neutral-500">Active Records:</span>
                  <div className="font-semibold text-neutral-200 print:text-black mt-0.5">{records.length} Reconciled Items</div>
                </div>
                <div>
                  <span className="text-neutral-500">Primary Data Share:</span>
                  <div className="font-semibold text-emerald-400 print:text-emerald-700 mt-0.5">88.5% (Tier 1 & 2)</div>
                </div>
              </div>

              {/* Core Quantitative Summary Table (ESRS E1-6) */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300 print:text-black">
                  1. Consolidated Greenhouse Gas Inventory (tCO₂e)
                </h3>
                <table className="w-full text-left text-xs border border-neutral-800 print:border-neutral-300">
                  <thead className="bg-neutral-950 text-neutral-400 print:bg-neutral-100 print:text-neutral-700">
                    <tr>
                      <th className="py-2 px-3">Emission Scope & Category</th>
                      <th className="py-2 px-3 text-right">Location-Based</th>
                      <th className="py-2 px-3 text-right">Market-Based</th>
                      <th className="py-2 px-3">Primary Verification Standard</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800 print:divide-neutral-300 font-mono text-neutral-200 print:text-black">
                    <tr>
                      <td className="py-2 px-3 font-sans">Scope 1: Direct Fuels & Fugitive Refrigerants</td>
                      <td className="py-2 px-3 text-right">{formatNumber(summary.scope1Tons, 2)}</td>
                      <td className="py-2 px-3 text-right">{formatNumber(summary.scope1Tons, 2)}</td>
                      <td className="py-2 px-3 font-sans text-neutral-400 print:text-neutral-600">Smart meter logs / EPA Hub 2024</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-sans">Scope 2: Purchased Electricity & District Heating</td>
                      <td className="py-2 px-3 text-right">{formatNumber(summary.scope2LocationBasedTons, 2)}</td>
                      <td className="py-2 px-3 text-right text-emerald-400 font-bold print:text-emerald-800">
                        {formatNumber(summary.scope2MarketBasedTons, 2)}
                      </td>
                      <td className="py-2 px-3 font-sans text-neutral-400 print:text-neutral-600">AIB EECS GOs & Green-e RECs</td>
                    </tr>
                    <tr>
                      <td className="py-2 px-3 font-sans">Scope 3: Upstream & Downstream Value Chain</td>
                      <td className="py-2 px-3 text-right">{formatNumber(summary.scope3Tons, 2)}</td>
                      <td className="py-2 px-3 text-right">{formatNumber(summary.scope3Tons, 2)}</td>
                      <td className="py-2 px-3 font-sans text-neutral-400 print:text-neutral-600">GHG Protocol Scope 3 Standard</td>
                    </tr>
                    <tr className="font-bold text-white print:text-black bg-neutral-950/40 print:bg-neutral-50 border-t border-neutral-700">
                      <td className="py-2.5 px-3 font-sans">Total Gross GHG Emissions</td>
                      <td className="py-2.5 px-3 text-right">{formatNumber(summary.totalGrossLocationTons, 2)}</td>
                      <td className="py-2.5 px-3 text-right text-emerald-400 print:text-emerald-800">
                        {formatNumber(summary.totalGrossMarketTons, 2)}
                      </td>
                      <td className="py-2.5 px-3 font-sans">CSRD Compliant Gross Total</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Energy Mix Table (ESRS E1-5) */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300 print:text-black">
                  2. Energy Consumption and Renewable Share (ESRS E1-5)
                </h3>
                <div className="grid grid-cols-3 gap-3 p-3 bg-neutral-950 rounded border border-neutral-800 print:border-neutral-300 text-xs">
                  <div>
                    <span className="text-neutral-500">Total Group Energy:</span>
                    <div className="font-mono font-bold text-white print:text-black text-sm mt-0.5">
                      {formatNumber(summary.energyTotalMWh, 1)} MWh
                    </div>
                  </div>
                  <div>
                    <span className="text-neutral-500">Certified Renewable Electricity:</span>
                    <div className="font-mono font-bold text-emerald-400 print:text-emerald-700 text-sm mt-0.5">
                      {formatNumber(summary.renewableEnergyMWh, 1)} MWh ({summary.renewableEnergyPercent}%)
                    </div>
                  </div>
                  <div>
                    <span className="text-neutral-500">Revenue Carbon Intensity:</span>
                    <div className="font-mono font-bold text-white print:text-black text-sm mt-0.5">
                      {summary.intensityPerMRevenue} tCO₂e / $M
                    </div>
                  </div>
                </div>
              </div>

              {/* Offsets & Removals Statement (ESRS E1-7) */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-300 print:text-black">
                  3. GHG Removals & Mitigation Financing (ESRS E1-7)
                </h3>
                <p className="text-xs text-neutral-400 print:text-neutral-700 leading-relaxed">
                  In strict conformity with ESRS E1 Paragraph 58, carbon credits are tracked separately and not subtracted from gross emissions totals. During FY2026, the reporting entity retired <strong className="text-neutral-200 print:text-black">{formatNumber(summary.retiredDurableRemovalsTons, 1)} tCO₂e</strong> of durable carbon removal instruments (Puro.earth CORC certified biochar BCR and Direct Air Capture with permanence rating exceeding 1,000 years).
                </p>
              </div>

              {/* Audit Sign-Off Block */}
              <div className="pt-6 border-t border-neutral-800 print:border-neutral-300 grid grid-cols-2 gap-8 text-[11px]">
                <div className="space-y-1">
                  <span className="text-neutral-500 block">Lead Preparer (Corporate Sustainability Officer):</span>
                  <div className="font-semibold text-neutral-200 print:text-black pt-6 border-b border-neutral-700 print:border-black">
                    Dr. Evelyn Vance, VP Sustainability & Climate Risk
                  </div>
                  <div className="text-neutral-500">Apex Global Technologies & Logistics Inc.</div>
                </div>

                <div className="space-y-1">
                  <span className="text-neutral-500 block">Independent Pre-Assurance Lead Auditor:</span>
                  <div className="font-semibold text-neutral-200 print:text-black pt-6 border-b border-neutral-700 print:border-black">
                    Marcus Sterling, Partner - ESG & Carbon Assurance Practice
                  </div>
                  <div className="text-neutral-500">BDO / KPMG Sustainability Advisory LLP</div>
                </div>
              </div>

              {/* Digital Hash */}
              <div className="pt-2 text-[10px] font-mono text-neutral-500 print:text-neutral-600 flex items-center justify-between">
                <span>Verification Cryptographic Hash: {auditHash}</span>
                <span>Generated: {auditTimestamp.split('T')[0]}</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>Machine-readable XBRL / ESEF Tagged JSON Payload (European Commission Delegated Act compliant)</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyJson}
                    className="flex items-center gap-1 px-3 py-1 bg-neutral-900 border border-neutral-800 rounded text-neutral-300 hover:text-white transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied JSON' : 'Copy JSON'}</span>
                  </button>
                  <button
                    onClick={handleDownloadXbrl}
                    className="flex items-center gap-1 px-3 py-1 bg-emerald-950 border border-emerald-800 rounded text-emerald-300 hover:bg-emerald-900 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download JSON File</span>
                  </button>
                </div>
              </div>

              <pre className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg text-xs font-mono text-emerald-300/90 overflow-x-auto leading-relaxed">
                {JSON.stringify(xbrlData, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-neutral-900 border-t border-neutral-800 flex items-center justify-between shrink-0">
          <div className="text-xs text-neutral-400">
            Validated against GHG Protocol Corporate Standard (2004) and ESRS E1 (2024).
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-800 hover:bg-neutral-700 rounded transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
