import React, { useState } from 'react';
import { RegulatoryMandate, SEED_REGULATORY_MANDATES } from '../data/seedData';
import { EmissionsSummary } from '../types/carbon';
import { formatTons, formatNumber } from '../utils/carbonEngine';
import { 
  ShieldAlert, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  FileCheck, 
  Scale, 
  Download, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  CheckSquare,
  Square
} from 'lucide-react';

interface RegulatoryHubViewProps {
  summary: EmissionsSummary;
  onOpenAuditExport: () => void;
  onNavigateToTab: (tab: string) => void;
}

export const RegulatoryHubView: React.FC<RegulatoryHubViewProps> = ({
  summary,
  onOpenAuditExport,
  onNavigateToTab
}) => {
  const [mandates, setMandates] = useState<RegulatoryMandate[]>(SEED_REGULATORY_MANDATES);
  const [selectedMandateId, setSelectedMandateId] = useState<string>(mandates[0]?.id || '');

  // Pre-Assurance Checklist state
  const [checklistItems, setChecklistItems] = useState([
    { id: 'chk_1', text: '100% of Scope 1 stationary gas and diesel fuel meters backed by calibrated utility billing manifests', checked: true, scope: 'Scope 1' },
    { id: 'chk_2', text: 'Dual Scope 2 accounting maintained with separate Location-based and Market-based calculations (GHG Protocol Scope 2)', checked: true, scope: 'Scope 2' },
    { id: 'chk_3', text: 'Contractual renewable energy instruments (EACs / Guarantees of Origin) verified with registry serial numbers', checked: true, scope: 'Scope 2' },
    { id: 'chk_4', text: 'Materiality threshold applied across all 15 Scope 3 categories with documented exclusion rationale for non-material streams', checked: true, scope: 'Scope 3' },
    { id: 'chk_5', text: 'Independent third-party limited assurance engagement letter signed under ISAE 3000 / 3410 standards', checked: true, scope: 'Governance' },
    { id: 'chk_6', text: 'Supplier engagement program initiated to transition top 40 semiconductor & freight vendors to Tier 1 primary PCFs', checked: false, scope: 'Scope 3' },
    { id: 'chk_7', text: 'Severe weather physical risk assessment updated for California and Rotterdam sites per California SB 261 / TCFD', checked: false, scope: 'Risk' }
  ]);

  const toggleChecklistItem = (id: string) => {
    setChecklistItems(prev => prev.map(item => item.id === id ? { ...item, checked: !item.checked } : item));
  };

  const selectedMandate = mandates.find(m => m.id === selectedMandateId) || mandates[0];
  const completedChecks = checklistItems.filter(c => c.checked).length;
  const auditReadinessScore = Math.round((completedChecks / checklistItems.length) * 100);

  return (
    <div className="space-y-6">
      {/* Urgency Hero Banner */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="font-semibold text-neutral-200 uppercase tracking-wider text-[11px]">Global Regulatory Enforcement Tracker</span>
            <span aria-hidden="true">·</span>
            <span>CSRD · SB 253 · SEC · CBAM</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-400 font-mono">Enforcement Live</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Regulatory Tailwinds & Buying Urgency Center
          </h2>
          <p className="text-xs text-neutral-300 mt-1 max-w-3xl">
            Global environmental disclosures have shifted from voluntary PR statements to legally binding statutory financial filings subject to auditor attestation and civil penalties.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg text-right font-mono">
            <span className="text-[10px] text-neutral-400 block">ASSURANCE READINESS</span>
            <span className="text-lg font-bold text-emerald-400">{auditReadinessScore}%</span>
          </div>

          <button
            onClick={onOpenAuditExport}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Auditor Evidence Pack</span>
          </button>
        </div>
      </div>

      {/* 4 Major Regulatory Mandate Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {mandates.map((m) => {
          const isSelected = selectedMandateId === m.id;
          return (
            <div
              key={m.id}
              onClick={() => setSelectedMandateId(m.id)}
              className={`p-4 rounded-lg border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-neutral-900 border-emerald-500 shadow-sm'
                  : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono text-[11px] text-neutral-400">{m.jurisdiction.split(' ')[0]}</span>
                <span className="font-mono font-bold text-emerald-400">{m.readinessScore}% Ready</span>
              </div>

              <h4 className="text-sm font-semibold text-white mt-2 line-clamp-1">
                {m.name}
              </h4>

              <div className="text-[11px] text-amber-300/90 font-mono mt-1 flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-400" />
                <span>{m.complianceDeadline.split('(')[0]}</span>
              </div>

              <div className="mt-3 pt-2.5 border-t border-neutral-800 text-[11px] text-neutral-400 flex items-center justify-between">
                <span>{m.assuranceLevel}</span>
                <span className="text-emerald-400 font-medium">{m.status}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Mandate Deep-Dive & Penalty Breakdown */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-neutral-800">
          <div>
            <span className="text-xs font-mono text-emerald-400">{selectedMandate.jurisdiction}</span>
            <h3 className="text-base font-bold text-white mt-0.5">{selectedMandate.name}</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-xs font-mono text-emerald-300 bg-emerald-950/70 border border-emerald-800 rounded">
              Status: {selectedMandate.status}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-neutral-950 rounded border border-neutral-800">
            <span className="text-neutral-500">Statutory Deadline:</span>
            <div className="text-white font-medium mt-1">{selectedMandate.complianceDeadline}</div>
          </div>
          <div className="p-3 bg-neutral-950 rounded border border-neutral-800">
            <span className="text-neutral-500">Assurance Standard:</span>
            <div className="text-white font-medium mt-1">{selectedMandate.assuranceLevel} (ISAE 3000)</div>
          </div>
          <div className="p-3 bg-neutral-950 rounded border border-amber-900/60 bg-amber-950/20">
            <span className="text-amber-400 font-semibold flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> Non-Compliance Liability:
            </span>
            <div className="text-amber-200 mt-1 text-[11px] leading-snug">{selectedMandate.nonCompliancePenalty}</div>
          </div>
        </div>

        {/* Mandatory Legal Requirements */}
        <div className="space-y-2 pt-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
            Core Filing Invariants & Mandatory Rules
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {selectedMandate.keyRequirements.map((req, idx) => (
              <div key={idx} className="p-2.5 bg-neutral-950/70 rounded border border-neutral-800/80 text-xs text-neutral-300 flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>{req}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pre-Assurance Limited Audit Readiness Checklist */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-white">Pre-Assurance Audit Checklist (ISAE 3000 Limited Assurance)</h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Verified controls required before signing external auditor engagement letter for statutory reporting
            </p>
          </div>
          <div className="text-xs text-neutral-400 font-mono">
            {completedChecks} of {checklistItems.length} Controls Verified ({auditReadinessScore}%)
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
          <div 
            className="bg-emerald-400 h-full rounded-full transition-all duration-300"
            style={{ width: `${auditReadinessScore}%` }}
          />
        </div>

        {/* Interactive Checklist Items */}
        <div className="space-y-2 pt-1">
          {checklistItems.map((item) => (
            <div
              key={item.id}
              onClick={() => toggleChecklistItem(item.id)}
              className="p-3 bg-neutral-950/70 border border-neutral-800/80 rounded-md flex items-start gap-3 cursor-pointer hover:border-neutral-700 transition-colors"
            >
              <button 
                type="button" 
                className="mt-0.5 text-neutral-400 focus:outline-none"
                onClick={(e) => {
                  e.stopPropagation();
                  toggleChecklistItem(item.id);
                }}
              >
                {item.checked ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Square className="w-4 h-4 text-neutral-600" />
                )}
              </button>

              <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                <span className={item.checked ? 'text-neutral-200' : 'text-neutral-400 line-through'}>
                  {item.text}
                </span>
                <span className="font-mono text-[10px] text-neutral-500 uppercase shrink-0">
                  {item.scope}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-3 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span>Digital Ledger Verification Hash: <strong className="text-white font-mono">sha256:8f2a991b0...c4e9</strong></span>
          <button
            onClick={() => onNavigateToTab('csrd')}
            className="text-emerald-400 hover:text-emerald-300 font-semibold"
          >
            Review ESRS E1 Report &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
