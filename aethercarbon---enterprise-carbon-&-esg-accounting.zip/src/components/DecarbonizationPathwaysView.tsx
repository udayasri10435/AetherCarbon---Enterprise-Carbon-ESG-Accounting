import React, { useState } from 'react';
import { DecarbonizationLever, EmissionsSummary } from '../types/carbon';
import { formatNumber, formatTons, formatCurrency } from '../utils/carbonEngine';
import { 
  TrendingDown, 
  Zap, 
  DollarSign, 
  Target, 
  Sliders, 
  CheckCircle2, 
  ArrowRight,
  Info,
  Layers,
  Sparkles
} from 'lucide-react';

interface DecarbonizationPathwaysViewProps {
  levers: DecarbonizationLever[];
  summary: EmissionsSummary;
  onUpdateLeverAdoption: (leverId: string, adoptionPercent: number) => void;
}

export const DecarbonizationPathwaysView: React.FC<DecarbonizationPathwaysViewProps> = ({
  levers,
  summary,
  onUpdateLeverAdoption
}) => {
  const [selectedScopeFilter, setSelectedScopeFilter] = useState<string>('all');

  // Baseline 2022: 4,820 tCO2e
  const baselineTons = 4820.0;
  const target2030Tons = 2390.0; // 50.4% reduction
  const target2040NetZeroResidual = 482.0; // 90% reduction

  // Calculate live abated tons from currently modeled lever adoptions
  const totalSimulatedAbatementTons = levers.reduce((acc, lever) => {
    return acc + (lever.abatementTonsPerYear * (lever.adoptionPercent / 100));
  }, 0);

  const totalSimulatedCapex = levers.reduce((acc, lever) => {
    return acc + (lever.capexUsd * (lever.adoptionPercent / 100));
  }, 0);

  const totalSimulatedOpexSavings = levers.reduce((acc, lever) => {
    return acc + (lever.opexAnnualSavingsUsd * (lever.adoptionPercent / 100));
  }, 0);

  // Projected 2030 gross emissions run rate
  const projected2030Gross = Math.max(0, summary.totalGrossMarketTons - (totalSimulatedAbatementTons * 0.7));
  const gapTo2030Target = projected2030Gross - target2030Tons;
  const isTargetAchieved = gapTo2030Target <= 0;

  // Filter levers by scope
  const filteredLevers = levers.filter((l) => {
    if (selectedScopeFilter === 'all') return true;
    return l.scopeImpacted.includes(selectedScopeFilter as any);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="font-semibold text-neutral-200">Science Based Targets initiative (SBTi)</span>
            <span aria-hidden="true">·</span>
            <span>1.5°C Net-Zero Corporate Standard</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-mono">MACC Scenario Engine</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Decarbonization Pathways & Scenario Modeling
          </h2>
          <p className="text-xs text-neutral-300 mt-1 max-w-3xl">
            Simulate capital expenditure, operational cost savings, and emissions abatement trajectories to close the 2030 Paris Agreement interim milestone.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <div className="p-2 bg-neutral-950 border border-neutral-800 rounded text-right">
            <span className="text-neutral-500 text-[10px] block">2030 SBTi CEILING</span>
            <span className="font-bold text-white">2,390.0 tCO₂e</span>
          </div>
          <div className={`p-2 border rounded text-right ${
            isTargetAchieved 
              ? 'bg-emerald-950/60 border-emerald-800 text-emerald-400' 
              : 'bg-amber-950/60 border-amber-800 text-amber-400'
          }`}>
            <span className="text-[10px] block opacity-80">PROJECTED RUN RATE</span>
            <span className="font-bold">{formatNumber(projected2030Gross, 1)} tCO₂e</span>
          </div>
        </div>
      </div>

      {/* Target Status KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Active Modeled Abatement</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            -{formatNumber(totalSimulatedAbatementTons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e/yr</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Across 5 strategic decarbonization levers
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Modeled Capital Investment (CAPEX)</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {formatCurrency(totalSimulatedCapex)}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            Taxonomy aligned energy transition
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Annual Operational Savings (OPEX)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {formatCurrency(totalSimulatedOpexSavings)}<span className="text-xs text-neutral-400 font-sans">/yr</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Reduced fuel bills and energy tariffs
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">2030 Interim Target Gap</div>
          <div className={`text-2xl font-bold font-mono mt-1 ${isTargetAchieved ? 'text-emerald-400' : 'text-amber-400'}`}>
            {isTargetAchieved ? 'Target Surpassed' : `+${formatNumber(gapTo2030Target, 1)} t Gap`}
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            {isTargetAchieved ? '1.5°C Paris aligned compliance' : 'Increase lever adoption to close gap'}
          </div>
        </div>
      </div>

      {/* Visual MACC: Marginal Abatement Cost Curve */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="text-sm font-semibold text-white">Marginal Abatement Cost Curve (MACC)</h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Net cost per ton abated ($/tCO₂e) vs annual emissions abatement potential (tCO₂e)
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs text-neutral-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-xs"></span>
              <span>Net Negative Cost (ROI Positive)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-sky-500 rounded-xs"></span>
              <span>Net Positive Cost</span>
            </span>
          </div>
        </div>

        {/* SVG MACC Chart */}
        <div className="pt-3 pb-2 overflow-x-auto">
          <svg viewBox="0 0 700 200" className="w-full h-auto min-w-[550px]">
            {/* Zero axis */}
            <line x1="40" y1="110" x2="680" y2="110" stroke="#525252" strokeWidth="1.5" />
            <text x="35" y="114" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">$0/t</text>
            <text x="35" y="40" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">+$40/t</text>
            <text x="35" y="180" textAnchor="end" className="text-[10px] fill-neutral-400 font-mono">-$30/t</text>

            {/* Grid references */}
            <line x1="40" y1="40" x2="680" y2="40" stroke="#262626" strokeDasharray="3,3" />
            <line x1="40" y1="180" x2="680" y2="180" stroke="#262626" strokeDasharray="3,3" />

            {/* Lever 1: Rooftop Solar (-$18.5/t, 320t) */}
            {/* x: 60, width: 110, y: 110, h: 42 (below axis) */}
            <rect x="60" y="110" width="110" height="42" fill="#10b981" fillOpacity="0.8" rx="2" />
            <text x="115" y="170" textAnchor="middle" className="text-[9px] fill-neutral-300 font-mono">Solar PV (-$18.5)</text>

            {/* Lever 2: vPPA Wind (-$12.0/t, 450t) */}
            {/* x: 175, width: 150, y: 110, h: 28 (below axis) */}
            <rect x="175" y="110" width="150" height="28" fill="#10b981" fillOpacity="0.8" rx="2" />
            <text x="250" y="155" textAnchor="middle" className="text-[9px] fill-neutral-300 font-mono">vPPA Wind (-$12.0)</text>

            {/* Lever 3: Supplier PCF (+4.5/t, 410t) */}
            {/* x: 330, width: 140, y: 99, h: 11 (above axis) */}
            <rect x="330" y="99" width="140" height="11" fill="#0284c7" fillOpacity="0.8" rx="2" />
            <text x="400" y="92" textAnchor="middle" className="text-[9px] fill-neutral-300 font-mono">Supplier Pact (+$4.5)</text>

            {/* Lever 4: Heat Pump (+12.0/t, 95t) */}
            {/* x: 475, width: 60, y: 83, h: 27 (above axis) */}
            <rect x="475" y="83" width="60" height="27" fill="#0284c7" fillOpacity="0.8" rx="2" />
            <text x="505" y="75" textAnchor="middle" className="text-[9px] fill-neutral-300 font-mono">Heat Pump (+$12)</text>

            {/* Lever 5: Fleet EV (+24.0/t, 180t) */}
            {/* x: 540, width: 100, y: 55, h: 55 (above axis) */}
            <rect x="540" y="55" width="100" height="55" fill="#0284c7" fillOpacity="0.8" rx="2" />
            <text x="590" y="47" textAnchor="middle" className="text-[9px] fill-neutral-300 font-mono">EV Fleet (+$24)</text>
          </svg>
        </div>
      </div>

      {/* Interactive Decarbonization Lever Sliders */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Interactive Decarbonization Levers (Scenario Tuning)</h3>
          
          <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-md text-xs">
            <button
              onClick={() => setSelectedScopeFilter('all')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedScopeFilter === 'all' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
              }`}
            >
              All Levers
            </button>
            <button
              onClick={() => setSelectedScopeFilter('scope_1')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedScopeFilter === 'scope_1' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
              }`}
            >
              Scope 1
            </button>
            <button
              onClick={() => setSelectedScopeFilter('scope_2')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedScopeFilter === 'scope_2' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
              }`}
            >
              Scope 2
            </button>
            <button
              onClick={() => setSelectedScopeFilter('scope_3')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedScopeFilter === 'scope_3' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'
              }`}
            >
              Scope 3
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {filteredLevers.map((lever) => {
            const currentAbated = (lever.abatementTonsPerYear * (lever.adoptionPercent / 100)).toFixed(1);
            const currentCapex = lever.capexUsd * (lever.adoptionPercent / 100);
            const currentSavings = lever.opexAnnualSavingsUsd * (lever.adoptionPercent / 100);

            return (
              <div 
                key={lever.id}
                className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg space-y-3 hover:border-neutral-700 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white">{lever.name}</span>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-1.5 py-0.2 rounded uppercase">
                        {lever.category}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-1 max-w-2xl">{lever.description}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold font-mono text-emerald-400">
                      -{currentAbated} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e/yr</span>
                    </div>
                    <div className="text-[11px] text-neutral-500 font-mono">
                      MAC: {lever.costPerTonAbated < 0 ? `-$${Math.abs(lever.costPerTonAbated)}` : `+$${lever.costPerTonAbated}`}/t
                    </div>
                  </div>
                </div>

                {/* Slider Row */}
                <div className="pt-2 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                  <div className="flex-1 flex items-center gap-3">
                    <span className="text-neutral-400 whitespace-nowrap">Adoption Rate:</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      step="5"
                      value={lever.adoptionPercent}
                      onChange={(e) => onUpdateLeverAdoption(lever.id, Number(e.target.value))}
                      className="w-full accent-emerald-400 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
                    />
                    <span className="font-mono font-bold text-white w-12 text-right">
                      {lever.adoptionPercent}%
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-[11px] text-neutral-400 font-mono shrink-0">
                    <span>CAPEX: <strong className="text-neutral-200">{formatCurrency(currentCapex)}</strong></span>
                    <span>OPEX Savings: <strong className="text-emerald-400">+{formatCurrency(currentSavings)}/yr</strong></span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
