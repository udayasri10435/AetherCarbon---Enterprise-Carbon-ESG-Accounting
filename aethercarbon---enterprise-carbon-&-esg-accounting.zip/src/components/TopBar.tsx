import React from 'react';
import { Plus, Download, Sparkles } from 'lucide-react';

interface TopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenLogModal: () => void;
  onOpenAuditExport: () => void;
  onOpenCopilot: () => void;
  verifiedPercent: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenLogModal,
  onOpenAuditExport,
  onOpenCopilot,
  verifiedPercent
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Executive Overview' },
    { id: 'ledger', label: 'Emissions Ledger' },
    { id: 'csrd', label: 'CSRD / ESRS E1' },
    { id: 'offsets', label: 'Offsets & EACs' },
    { id: 'pathways', label: 'SBTi Pathways' },
    { id: 'regulatory', label: 'Regulatory Hub' }
  ];

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between px-6 py-3.5 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-6">
        <a 
          href="#dashboard" 
          onClick={(e) => { e.preventDefault(); setActiveTab('dashboard'); }}
          className="text-lg font-bold tracking-tight text-white flex items-center gap-2 select-none hover:opacity-90 transition-opacity"
        >
          <div className="w-6 h-6 rounded bg-emerald-500 flex items-center justify-center text-neutral-950 font-black text-xs">
            ▲
          </div>
          <span>AetherCarbon</span>
        </a>

        {/* Clean subtle metadata */}
        <div className="hidden lg:flex items-center gap-2 text-xs text-neutral-400">
          <span>Apex Global Tech Inc.</span>
          <span aria-hidden="true">·</span>
          <span>FY2026 Reporting</span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-400 tabular-nums">{verifiedPercent}% Auditor Verified</span>
        </div>
      </div>

      {/* Zone 2: Clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-400">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`transition-colors whitespace-nowrap py-1 border-b-2 ${
                isActive
                  ? 'text-white border-emerald-400 font-semibold'
                  : 'text-neutral-400 hover:text-neutral-200 border-transparent'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenCopilot}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-900 border border-neutral-800 rounded-md hover:bg-neutral-800 hover:text-white transition-colors"
          title="Open AI Compliance & Carbon Copilot"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">AI ESG Copilot</span>
        </button>

        <button
          onClick={onOpenAuditExport}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-900 border border-neutral-800 rounded-md hover:bg-neutral-800 hover:text-white transition-colors"
        >
          <Download className="w-3.5 h-3.5 text-neutral-400" />
          <span className="hidden sm:inline">Export Audit Pack</span>
        </button>

        <button
          onClick={onOpenLogModal}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors font-semibold shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log Activity</span>
        </button>
      </div>
    </header>
  );
};
