import React, { useState } from 'react';
import { 
  CSRDDisclosureSection, 
  EmissionsSummary, 
  ActivityRecord,
  CarbonOffset,
  EACCertificate 
} from '../types/carbon';
import { 
  formatTons, 
  formatNumber, 
  formatCurrency 
} from '../utils/carbonEngine';
import { generateDisclosureNarrativeWithAI } from '../utils/aiCopilot';
import { 
  FileCheck2, 
  Sparkles, 
  Download, 
  CheckCircle, 
  Clock, 
  BookOpen, 
  ChevronDown, 
  ChevronUp, 
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Edit3,
  Check
} from 'lucide-react';

interface CsrdReportingViewProps {
  disclosures: CSRDDisclosureSection[];
  summary: EmissionsSummary;
  records: ActivityRecord[];
  offsets: CarbonOffset[];
  eacs: EACCertificate[];
  onUpdateDisclosureNarrative: (id: string, narrative: string) => void;
  onOpenAuditExport: () => void;
}

export const CsrdReportingView: React.FC<CsrdReportingViewProps> = ({
  disclosures,
  summary,
  records,
  offsets,
  eacs,
  onUpdateDisclosureNarrative,
  onOpenAuditExport
}) => {
  const [expandedSectionId, setExpandedSectionId] = useState<string>(disclosures[0]?.id || '');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editNarrativeText, setEditNarrativeText] = useState<string>('');
  const [generatingForId, setGeneratingForId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const filteredDisclosures = disclosures.filter((d) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'mandatory') return d.mandatoryUnderCsrd;
    if (activeFilter === 'assurance') return d.progressStatus === 'Ready for Limited Assurance' || d.progressStatus === 'Compliant';
    return true;
  });

  const handleStartEdit = (d: CSRDDisclosureSection) => {
    setEditingId(d.id);
    setEditNarrativeText(d.narrativeDraft);
  };

  const handleSaveEdit = (id: string) => {
    onUpdateDisclosureNarrative(id, editNarrativeText);
    setEditingId(null);
  };

  const handleGenerateAI = async (d: CSRDDisclosureSection) => {
    setGeneratingForId(d.id);
    try {
      const generated = await generateDisclosureNarrativeWithAI(d, summary);
      onUpdateDisclosureNarrative(d.id, generated);
      if (editingId === d.id) {
        setEditNarrativeText(generated);
      }
    } finally {
      setGeneratingForId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Regulatory Context */}
      <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="font-semibold text-neutral-200">European Sustainability Reporting Standards</span>
            <span aria-hidden="true">·</span>
            <span>Directive (EU) 2022/2464</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-mono">ISAE 3000 Pre-Audit</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            ESRS E1 Climate Change Regulatory Disclosures
          </h2>
          <p className="text-xs text-neutral-300 mt-1 max-w-3xl">
            Audit-grade, digital XBRL-compatible disclosure statements mapped to European Commission delegated act standards. Synchronized continuously with verified ledger telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenAuditExport}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Generate Official Audit Pack</span>
          </button>
        </div>
      </div>

      {/* Compliance Health Scorecard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">ESRS E1 Requirements Ready</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            6 / 6 <span className="text-xs font-normal text-emerald-400 font-sans">100% Covered</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            E1-1, E1-2, E1-4, E1-5, E1-6, E1-7, E1-8
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Gross Scope 1/2/3 Disclosed</div>
          <div className="text-2xl font-bold font-mono text-white mt-1">
            {formatNumber(summary.totalGrossMarketTons, 1)} <span className="text-xs font-normal text-neutral-400 font-sans">tCO₂e</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Dual reporting compliant (Location & Market)
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Renewable Energy Share (E1-5)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {summary.renewableEnergyPercent}%
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            {formatNumber(summary.renewableEnergyMWh, 0)} MWh from AIB Guarantees of Origin
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div className="text-xs text-neutral-400">Assurance Standard</div>
          <div className="text-lg font-bold font-mono text-white mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>ISAE 3000 / 3410</span>
          </div>
          <div className="text-[11px] text-neutral-400 mt-1">
            Limited Assurance ready for FY2026 filing
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-neutral-400">Filter Disclosures:</span>
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-md">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1 rounded transition-colors ${
              activeFilter === 'all' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All Standard Disclosures ({disclosures.length})
          </button>
          <button
            onClick={() => setActiveFilter('mandatory')}
            className={`px-3 py-1 rounded transition-colors ${
              activeFilter === 'mandatory' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Mandatory Only (5)
          </button>
          <button
            onClick={() => setActiveFilter('assurance')}
            className={`px-3 py-1 rounded transition-colors ${
              activeFilter === 'assurance' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Assurance Verified
          </button>
        </div>
      </div>

      {/* Disclosure Sections Accordion / Cards */}
      <div className="space-y-4">
        {filteredDisclosures.map((d) => {
          const isExpanded = expandedSectionId === d.id;
          const isEditing = editingId === d.id;
          const isGenerating = generatingForId === d.id;

          return (
            <div
              key={d.id}
              className={`border rounded-lg overflow-hidden transition-colors ${
                isExpanded ? 'bg-neutral-900 border-neutral-700' : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
              }`}
            >
              {/* Header Row */}
              <div
                onClick={() => setExpandedSectionId(isExpanded ? '' : d.id)}
                className="p-4 flex items-center justify-between cursor-pointer select-none"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <span className="font-mono font-bold text-xs text-emerald-400 bg-neutral-950 border border-neutral-800 px-2 py-1 rounded">
                    {d.code}
                  </span>
                  <div>
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <span>{d.title}</span>
                      {d.mandatoryUnderCsrd && (
                        <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 border border-amber-800/80 px-1.5 py-0.2 rounded uppercase">
                          Mandatory
                        </span>
                      )}
                    </h3>
                    <p className="text-xs text-neutral-400 mt-0.5 line-clamp-1">{d.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="hidden md:block text-right">
                    <div className="font-mono text-xs font-semibold text-white">{d.metricValue}</div>
                    <div className="text-[11px] text-neutral-500">{d.baselineYearValue}</div>
                  </div>

                  <span className="text-emerald-400 text-xs flex items-center gap-1 font-medium">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{d.progressStatus}</span>
                  </span>

                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-neutral-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-400" />
                  )}
                </div>
              </div>

              {/* Expanded Content Drawer */}
              {isExpanded && (
                <div className="p-5 border-t border-neutral-800 bg-neutral-950/70 space-y-4 text-xs">
                  {/* Quantitative Data Points Bar */}
                  <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-md grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <span className="text-neutral-500">Reported Metric Value:</span>
                      <div className="font-mono font-bold text-white text-sm mt-0.5">{d.metricValue}</div>
                    </div>
                    <div>
                      <span className="text-neutral-500">Regulatory Citation:</span>
                      <div className="text-neutral-300 font-mono text-[11px] mt-0.5 truncate">{d.regulatoryReference}</div>
                    </div>
                    <div>
                      <span className="text-neutral-500">Coverage Scope:</span>
                      <div className="text-emerald-400 font-medium mt-0.5">{d.linkedScope}</div>
                    </div>
                  </div>

                  {/* Qualitative Narrative Section */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-neutral-300 uppercase tracking-wider text-[11px]">
                        Auditor-Verified Disclosure Narrative (ESRS Format)
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleGenerateAI(d)}
                          disabled={isGenerating}
                          className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-emerald-300 bg-emerald-950/70 border border-emerald-800/80 rounded hover:bg-emerald-900 transition-colors disabled:opacity-50"
                        >
                          <Sparkles className="w-3 h-3 text-emerald-400" />
                          <span>{isGenerating ? 'Drafting with AI...' : 'Refresh with AI Copilot'}</span>
                        </button>

                        {!isEditing ? (
                          <button
                            onClick={() => handleStartEdit(d)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded transition-colors"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit Text</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleSaveEdit(d.id)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs text-neutral-950 font-semibold bg-emerald-400 hover:bg-emerald-300 rounded transition-colors"
                          >
                            <Check className="w-3 h-3" />
                            <span>Save Narrative</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {isEditing ? (
                      <textarea
                        rows={5}
                        value={editNarrativeText}
                        onChange={(e) => setEditNarrativeText(e.target.value)}
                        className="w-full p-3 bg-neutral-900 border border-neutral-700 rounded-md text-xs text-neutral-100 font-sans leading-relaxed focus:outline-none focus:border-emerald-500"
                      />
                    ) : (
                      <div className="p-3.5 bg-neutral-900/90 border border-neutral-800 rounded-md text-xs text-neutral-300 leading-relaxed font-sans whitespace-pre-line">
                        {d.narrativeDraft}
                      </div>
                    )}
                  </div>

                  {/* Special Table for E1-5 (Energy Consumption & Mix) */}
                  {d.code === 'ESRS E1-5' && (
                    <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-md space-y-2">
                      <span className="font-semibold text-neutral-300 uppercase tracking-wider text-[11px]">
                        Table E1-5: Energy Breakdown by Source (MWh)
                      </span>
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-neutral-800 text-neutral-400 font-medium">
                            <th className="py-1.5">Energy Category</th>
                            <th className="py-1.5 text-right">MWh Volume</th>
                            <th className="py-1.5 text-right">% Mix</th>
                            <th className="py-1.5 text-right">Verification Basis</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-800/60 font-mono text-neutral-300">
                          <tr>
                            <td className="py-1.5 font-sans">Purchased Electricity (Grid + PPA)</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.energyTotalMWh * 0.784, 1)} MWh</td>
                            <td className="py-1.5 text-right">78.4%</td>
                            <td className="py-1.5 text-right text-emerald-400 font-sans">AIB EECS GOs</td>
                          </tr>
                          <tr>
                            <td className="py-1.5 font-sans">Direct Fossil Fuels (Natural Gas & Diesel)</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.energyTotalMWh * 0.216, 1)} MWh</td>
                            <td className="py-1.5 text-right">21.6%</td>
                            <td className="py-1.5 text-right text-neutral-400 font-sans">Utility Invoices</td>
                          </tr>
                          <tr className="font-bold text-white border-t border-neutral-700">
                            <td className="py-1.5 font-sans">Total Group Energy Consumption</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.energyTotalMWh, 1)} MWh</td>
                            <td className="py-1.5 text-right">100.0%</td>
                            <td className="py-1.5 text-right text-emerald-400 font-sans">ISAE 3000 Ready</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* Special Table for E1-6 (Gross Scopes 1, 2, 3 Breakdown) */}
                  {d.code === 'ESRS E1-6' && (
                    <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-md space-y-2">
                      <span className="font-semibold text-neutral-300 uppercase tracking-wider text-[11px]">
                        Table E1-6: Gross GHG Emissions and Intensity
                      </span>
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-neutral-800 text-neutral-400 font-medium">
                            <th className="py-1.5">Scope Breakdown</th>
                            <th className="py-1.5 text-right">Location-Based (tCO₂e)</th>
                            <th className="py-1.5 text-right">Market-Based (tCO₂e)</th>
                            <th className="py-1.5 text-right">YoY Change</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-neutral-800/60 font-mono text-neutral-300">
                          <tr>
                            <td className="py-1.5 font-sans">Scope 1 (Direct Fuel & Fugitive)</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.scope1Tons, 1)}</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.scope1Tons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400">-12.4%</td>
                          </tr>
                          <tr>
                            <td className="py-1.5 font-sans">Scope 2 (Purchased Electricity & Steam)</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.scope2LocationBasedTons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400 font-bold">{formatNumber(summary.scope2MarketBasedTons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400">-46.8%</td>
                          </tr>
                          <tr>
                            <td className="py-1.5 font-sans">Scope 3 (Upstream & Downstream Value Chain)</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.scope3Tons, 1)}</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.scope3Tons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400">-18.1%</td>
                          </tr>
                          <tr className="font-bold text-white border-t border-neutral-700">
                            <td className="py-1.5 font-sans">Total Gross GHG Emissions</td>
                            <td className="py-1.5 text-right">{formatNumber(summary.totalGrossLocationTons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400">{formatNumber(summary.totalGrossMarketTons, 1)}</td>
                            <td className="py-1.5 text-right text-emerald-400">-28.5%</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* Auditor Traceability Footer */}
                  <div className="pt-2 flex items-center justify-between text-[11px] text-neutral-500">
                    <span>Underlying Records: {records.length} line items reconciled</span>
                    <button
                      onClick={onOpenAuditExport}
                      className="text-emerald-400 hover:text-emerald-300 font-medium"
                    >
                      Inspect in Audit Export Pack &rarr;
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
